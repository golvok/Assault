/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game.gameObjects;

/**
 *an uninteractable part of the terrain
 * @author matt
 */
public class ATerrainObject extends APaintable{

	public ATerrainObject() {
		super(0, 0, 0, 0);
	}

}
