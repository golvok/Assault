/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.util;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author matt
 */
public class GridManager {

	//private static final int NULL_EMPTY_VALUE = -1;
	private static final int DEFAULT_SIZE = 64;
	private int gridSize;
	private int width;
	private int height;
	private final GridObject[][] grid;
	private List<GridObject> gObjects = Collections.synchronizedList(new ArrayList<GridObject>(DEFAULT_SIZE));
	//private int[] empties = new int[DEFAULT_SIZE];

	public GridManager(int pixelWidth, int pixelHeight, int gridSize) {
		this.gridSize = gridSize;
		this.width = convDimToGrid(pixelWidth, 0);
		this.height = convDimToGrid(pixelHeight, 0);
		grid = new GridObject[convDimToGrid(pixelWidth, 0)][convDimToGrid(pixelHeight, 0)];
		//removeAll();
	}

	/**
	 * add an GridObject to this GridManager
	 * @param go
	 * @return true if successful, false if not
	 */
	public boolean add(GridObject go) {
		synchronized (grid) {
			int x = convCoordToGrid(go.getX());
			int y = convCoordToGrid(go.getY());
			int widthInGrid = convDimToGrid(go.getWidth(), go.getX());
			int heightInGrid = convDimToGrid(go.getHeight(), go.getY());

			//check if where it wants to go is clear
			if (!canBeAtAMP(go.getX(), go.getY(), go)) {
				return false;
			}
			//add it to the list
			gObjects.add(go);
			//put it in the new location
			for (int k = 0; k < widthInGrid; k++) {
				for (int j = 0; j < heightInGrid; j++) {
					setCell(x + k, y + j, go);
				}
			}
		}
		return true;
	}

	public void remove(GridObject go) {
		synchronized (grid) {
			int x = convCoordToGrid(go.getX());
			int y = convCoordToGrid(go.getY());
			int widthInGrid = convDimToGrid(go.getWidth(), go.getX());
			int heightInGrid = convDimToGrid(go.getHeight(), go.getY());
			//remove it from the old location
			for (int i = 0; i < widthInGrid; i++) {
				for (int j = 0; j < heightInGrid; j++) {
					try {
						setCell(x + i, y + j, null);
					} catch (ArrayIndexOutOfBoundsException e) {
					}
				}
			}
			gObjects.remove(go);
		}
		System.out.println("GM_REMOVE");
	}

	public void removeAll() {
		gObjects.removeAll(gObjects);
	}

	/**
	 * moves the object in the GridManager
	 * should be called before when x and y are actually changed
	 * and used as a decision weather to do so or not.
	 * Also do not change the size between this and the movement
	 * @param ao
	 * @param newX
	 * @param newY
	 * @return (movementWasSuccessful)
	 */
	public boolean notifyOfImminentMovement(GridObject ao, Point oldPt, Point newPt) {
		return notifyOfImminentMovement(ao, oldPt.x, oldPt.y, newPt.x, newPt.y);
	}

	/**
	 * moves the object in the GridManager
	 * should be called before when x and y are actually changed
	 * and used as a decision weather to do so or not.
	 * Also do not change the size between this and the movement
	 * @param go
	 * @param newX
	 * @param newY
	 * @return (movementWasSuccessful)
	 */
	public boolean notifyOfImminentMovement(GridObject go, int oldX, int oldY, int newX, int newY) {
		//System.out.println("oldX = "+oldX);
		//System.out.println("oldY = "+oldY);
		//System.out.println("newX = "+newX);
		//System.out.println("newY = "+newY);
		int widthInGridOld = convDimToGrid(go.getWidth(), oldX);
		int heightInGridOld = convDimToGrid(go.getHeight(), oldY);
		int widthInGridNew = convDimToGrid(go.getWidth(), newX);
		int heightInGridNew = convDimToGrid(go.getHeight(), newY);

		//check if where it wants to go is clear
		if (!canBeAtAMP(newX, newY, go)) {
			System.out.println("GM: where it wants to go is not open @move");
			return false;
		}
		//System.out.println("GM: where it wants to go is clear @move");

		oldX = convCoordToGrid(oldX);
		oldY = convCoordToGrid(oldY);
		newX = convCoordToGrid(newX);
		newY = convCoordToGrid(newY);

		try {
			//check if it is indeed where it says it is
			for (int i = 0; i < widthInGridOld; i++) {
				for (int j = 0; j < heightInGridOld; j++) {
					if (getGoAt(oldX + i, oldY + j) != go) {
						System.out.println("GM: NOT where it says it is @move");
						//System.out.println("a "+getGoAt(oldX + i, oldY + j)+" is there!");
						//System.out.println("a "+go+" should be there!");
						return false;
					}
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			//only checks have been done, therefore there is nothing to clean up
			return false;
		}
		//System.out.println("GM: where it says it is @move");

		//remove it from the old location
		for (int i = 0; i < widthInGridOld; i++) {
			for (int j = 0; j < heightInGridOld; j++) {
				setCell(oldX + i, oldY + j, null);
			}
		}
		//put it in the new location
		for (int i = 0; i < widthInGridNew; i++) {
			for (int j = 0; j < heightInGridNew; j++) {
				setCell(newX + i, newY + j, go);
			}
		}
		return true;
	}

	/**
	 *
	 * @param x
	 * @param y
	 * @param ao
	 * @throws ArrayIndexOutOfBoundsException if it's well.. out of bounds...
	 */
	private void setCell(int x, int y, GridObject ao) throws ArrayIndexOutOfBoundsException {
		try {
			grid[x][y] = ao;
			//System.out.println("set (" + x + "," + y + ") to " + ao);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("cell (" + x + "," + y + ") is out of bounds");
			throw e;
		}
	}

	/**
	 *
	 * @param x
	 * @param y
	 * @return
	 * @throws ArrayIndexOutOfBoundsException if it's well.. out of bounds...
	 */
	public boolean isCellNull(int x, int y) throws ArrayIndexOutOfBoundsException {
		return getGoAt(x, y) == null;
	}

	/**
	 *
	 * @param x
	 * @param y
	 * @return
	 * @throws ArrayIndexOutOfBoundsException if it's well.. out of bounds...
	 */
	public GridObject getGoAtPixel(int x, int y) throws ArrayIndexOutOfBoundsException {
		return getGoAt(convCoordToGrid(x), convCoordToGrid(y));
	}

	/**
	 *
	 * @param x
	 * @param y
	 * @throws ArrayIndexOutOfBoundsException if it's well.. out of bounds...
	 */
	public GridObject getGoAt(int x, int y) throws ArrayIndexOutOfBoundsException {
		try {
			//System.out.println("cell ("+x+","+y+") is "+grid[x][y]);
			return grid[x][y];
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("cell (" + x + "," + y + ") is out of bounds");
			throw e;
		}
	}

	/**
	 * using grid co-ords, tests if if <code>go</code> can exist at (<code>GridX, GridY</code>)
	 * This method assumes that <code>go</code> is checking if it needs
	 * to be perfectly aligned with the grid at it's origin
	 * @param GridX in the Grid
	 * @param GridY in the Grid
	 * @param go
	 * @return 
	 */
	public boolean canBeAtGrid(int GridX, int GridY, GridObject go) {
		int w = convDimToGrid(go.getWidth(), 0);
		int h = convDimToGrid(go.getHeight(), 0);
		try {
			for (int i = GridX; i < GridX + w; i++) {
				for (int j = GridY; j < GridY + h; j++) {
					//System.out.println("testing " + i + "," + j + " : " + getGoAt(i, j));
					if (!isCellNull(i, j) && getGoAt(i, j) != go) {
						//System.out.println("can't be here @CBA");
						return false;
					}
				}
			}
		} catch (ArrayIndexOutOfBoundsException aiobe) {
			System.out.println("out of bounds @CBAG");
			return false;

		}
		return true;
	}

	/**
	 * using AMP co-ords, tests if <code>go</code> can exist at (<code>AMPx, AMPy</code>)
	 * @param AMPx in the AMP
	 * @param AMPy in the AMP
	 * @param go
	 * @return 
	 */
	public boolean canBeAtAMP(int AMPx, int AMPy, GridObject go) {
		int w = convDimToGrid(go.getWidth(), AMPx);
		int h = convDimToGrid(go.getHeight(), AMPy);
		int GridX = convCoordToGrid(AMPx);
		int GridY = convCoordToGrid(AMPy);
		try {
			for (int i = GridX; i < GridX + w; i++) {
				for (int j = GridY; j < GridY + h; j++) {
					//System.out.println("testing " + i + "," + j + " : " + getGoAt(i, j));
					if (!isCellNull(i, j) && getGoAt(i, j) != go) {
						//System.out.println("can't be here @CBA");
						return false;
					}
				}
			}
		} catch (ArrayIndexOutOfBoundsException aiobe) {
			System.out.println("out of bounds @CBAA");
			return false;

		}
		return true;


	}

	/**
	 * should be used to convert an x or y to the grid.
	 * <p>
	 * conversion process: if num % gridsize == 0 it divides by gridSize.
	 * if not, it ceils that same equation.
	 * @param num
	 * @return the grid normalized index equivalent of num
	 */
	public final int convCoordToGrid(int num) {
		if (num % gridSize == 0) {
			return (num / gridSize);
		} else {
			return /*int i = */ (int) Math.ceil((num) / (gridSize));
			//System.out.println("converted " + num + "(coord) to " + i);
			//return i;
		}
	}

	/**
	 * should be used to convert a width or height to the grid.
	 * the <code>AMPcoord</code> parameter should be the corresponding coordinate
	 * singlet (either x or y for width and height respectively)
	 * associated with that dimension. this allows the method to
	 * account for if <code>go</code> occupies more cells than it is long.
	 * for example if the <code>AMPdim</code> was 25 long but started at 7
	 * it used to convert to 3 (if gridSize was 10) but it
	 * would actually occupy 4:<br>
	 * <code>0--10--20--30-40<br>
	 *       |  .|...|...|.  |</code>
	 * <code>if (AMPcoord + dim) % gridsize == 0</code> then it just ceils <code>AMPdim</code>/gridsize .
	 * this is when the go fits perfectly in an even number of gridspaces and
	 * the special accommodations for when it doesn't are not necessary and generate
	 * incorrect numbers if used
	 * @param AMPdim the dimension
	 * @param AMPcoord the corresponding coordinate singlet (w --> x and h --> y)
	 * @return the converted dimension
	 */
	public final int convDimToGrid(int AMPdim, int AMPcoord) {
		if (AMPcoord >= 0) {
			if (AMPcoord % gridSize == 0 || (AMPcoord + AMPdim) % gridSize == 0) {
				return (int) Math.ceil(((double) AMPdim) / ((double) gridSize));
			} else {
				return (int) Math.ceil(((double) ((AMPcoord % gridSize) + AMPdim)) / (double) (gridSize));
			}
		} else {
			return 0;
		}
	}

	/**
	 * should be used to convert an grid x or y to an actual pixel x or y.
	 * <p>
	 * conversion process: multiplies by gridSize.
	 * @param num
	 * @return num*gridSize
	 */
	public final int convGridToPixel(int num) {
		return num * gridSize;
	}

	/**
	 * creates a rectangle that is the space in the grid that go occupies
	 * @param go
	 * @return
	 */
	public Rectangle getGridbox(GridObject go) {
		return new Rectangle(convCoordToGrid(go.getX()), convCoordToGrid(go.getY()), convDimToGrid(go.getWidth(), go.getX()), convDimToGrid(go.getHeight(), go.getY()));
	}

	public int getGridSize() {
		return gridSize;
	}

	public int getGridHeight() {
		return height;
	}

	public int getGridWidth() {
		return width;
	}

	public int getPixelHeight() {
		return convDimToGrid(height, 0);
	}

	public int getPixelWidth() {
		return convDimToGrid(width, 0);
	}
}
