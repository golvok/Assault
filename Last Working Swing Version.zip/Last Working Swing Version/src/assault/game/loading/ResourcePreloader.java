/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.loading;

import assault.game.display.GameArea;
import assault.game.loading.resourceHolders.BadlyFormattedXMLException;
import assault.game.loading.resourceHolders.ModResourceHolder;
import assault.game.loading.resourceHolders.ResourceHolderException;
import assault.game.loading.resourceHolders.UnitResourceHolder;
import assault.game.loading.resourceHolders.WeaponResourceHolder;
import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author matt
 */
public class ResourcePreloader extends JComponent {

	private ImageIcon[] commandImages = new ImageIcon[6];
	//if any more of these are added make sure there is room in the array for them
	public static final int MOVE_CMD_IMAGE_INDEX = 0;
	public static final int CREATE_CMD_IMAGE_INDEX = 1;
	private String statusString = "";
	private ArrayList<Exception> errors = new ArrayList<Exception>(10);
	private ModResourceHolder[] mods;
	private String[] modNames;
	private SAXBuilder builder;
	private GameArea amp;
	private boolean started = false;

	public ResourcePreloader(String[] mods, GameArea amp) {
		super();
		modNames = mods;
		this.amp = amp;
		//setBorder(BorderFactory.createLineBorder(Color.black, 3));
		setBounds(0, 0, amp.getWidth(), amp.getHeight());
	}

	public void start() {
		if (!started) {
			started = true;
			try {
				amp.add(this);
				setStatusString("initializing preLoader");
				mods = new ModResourceHolder[modNames.length];
				builder = new SAXBuilder();

				setStatusString("loading command icons...");
				commandImages[MOVE_CMD_IMAGE_INDEX] = new ImageIcon(ImageIO.read(getClass().getResourceAsStream("/assault/game/util/commands/imagesUsedForIcons/" + "Move" + "Cmd_Icon.png")));

				commandImages[CREATE_CMD_IMAGE_INDEX] = new ImageIcon(ImageIO.read(getClass().getResourceAsStream("/assault/game/util/commands/imagesUsedForIcons/" + "Create" + "Cmd_Icon.png")));

			} catch (IOException ex) {
				addError("trouble accessing cmdIcon images");
			}

			setStatusString("creating mods...");
			for (int i = 0; i < mods.length; i++) {
				try {
					this.mods[i] = new ModResourceHolder(modNames[i], this, builder);
				} catch (ResourceHolderException ex) {
					addError("did not create " + modNames[i] + " mod!\n\tMessage : " + ex.getReason());
				}
			}

			setStatusString("loading mods...");
			for (int i = 0; i < mods.length; i++) {
				if (mods[i] != null) {
					try {
						mods[i].load();
					} catch (ResourceHolderException ex) {
						addError("did not load " + modNames[i] + " mod!\n\tMessage : " + ex.getReason());
					}
				}
			}
			for (int i = 0; i < mods.length; i++) {
				if (mods[i] != null) {
					try {
						mods[i].loadReferencial();
					} catch (ResourceHolderException ex) {
						addError("did not load " + modNames[i] + " mod!\n\tMessage : " + ex.getReason());
					}
				}
			}
			setStatusString("done loading!");
			//setStatusString("");

			/*if (getParent() != null) {
			getParent().remove(this);
			}*/
		}
	}

	public void setStatusString(String status) {
		if (status != null) {
			statusString = status;
			System.out.println(status);
		}
		repaint();
		//repaint(30, 0, 20, getWidth());
	}

	public SAXBuilder getBuilder() {
		return builder;
	}

	public ModResourceHolder getModByName(String name) throws ResourceHolderException {
		for (int i = 0; i < mods.length; i++) {
			if (mods[i] != null && mods[i].getName().equals(name)) {
				return mods[i];
			}
		}
		throw new ResourceHolderException("getModByName: the " + name + " mod doesn't exist");
	}

	public UnitResourceHolder getModUnitByName(String modName, String unitName) throws ResourceHolderException {
		ModResourceHolder mod = getModByName(modName);
		UnitResourceHolder unit = mod.getUnitByName(unitName);
		if (unit != null) {
			return unit;
		} else {
			throw new ResourceHolderException("getModUnitByName: " + modName + "." + unitName + " doesn't exist");
		}
	}

	public WeaponResourceHolder getModWeaponByName(String modName, String weaponName) throws ResourceHolderException {
		ModResourceHolder mod = getModByName(modName);
		WeaponResourceHolder weapon = mod.getWeaponByName(weaponName);
		if (weapon != null) {
			return weapon;
		} else {
			throw new ResourceHolderException("getModWeaponByName: " + modName + "." + weaponName + " doesn't exist");
		}
	}

	public ImageIcon getCmdIcon(int index) {
		if (index >= 0 && index < commandImages.length) {
			return commandImages[index];
		} else {
			return null;
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawString(statusString, 0, 50);
		//System.out.println("RP_PAINT");
	}

	public synchronized void addError(String message) {
		addError(new ResourceHolderException(message));
	}

	public void addError(ResourceHolderException e) {
		System.out.println("!!!!!!  " + e.getReason());
		errors.add(e);
	}
}
