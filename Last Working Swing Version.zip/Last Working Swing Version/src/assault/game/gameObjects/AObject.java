/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.gameObjects;

import assault.game.APlayer;
import assault.game.display.GameArea;
import assault.AGameViewer;
import assault.game.display.AStatusDisplayBox;
import assault.game.util.GridObject;
import assault.game.loading.resourceHolders.ObjectResourceHolder;
import assault.game.loading.resourceHolders.ResourceHolderException;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 *
 * @author matt
 */
public class AObject extends APaintable implements MouseListener, GridObject {

	public final static int CROSS_SIZE = 4;
	private APlayer owner;
	private int maxHealth = 1;
	private int health = 1;
	private boolean invincible = false;
	private boolean selected = false;
	private boolean paintCross = true;
	private boolean showStatus = true;
	private AStatusDisplayBox statDispBox = null;
	private Image miniIcon = null;
	private ObjectResourceHolder src = null;
	private final Image naturalImage;
	private boolean disposed = false;
	private boolean alive = true;

	public AObject(int x, int y, ObjectResourceHolder src, int health, APlayer owner) throws ResourceHolderException {
		this(x, y, src.getWidth(), src.getHeight(), health, src.getMaxHealth(), src.getMiniIcon(), src.getBaseImage(owner), owner);
		if (!src.isValid()) {
			throw new ResourceHolderException("supplied resource holder for new object (" + src.getQualifiedName() + ") is invalid!");
		}
		this.src = src;
	}

	public AObject(int x, int y, ObjectResourceHolder src, APlayer owner) throws ResourceHolderException {
		this(x, y, src, src.getMaxHealth(), owner);
	}

	public AObject(int x, int y, int width, int height, int maxHealth, Image miniIcon, Image naturalImage, APlayer owner) {
		this(x, y, width, height, maxHealth, maxHealth, miniIcon, naturalImage, owner);
	}

	public AObject(int x, int y, int width, int height, int health, int maxHealth, Image miniIcon, Image naturalImage, APlayer owner) {
		this(x, y, width, height, miniIcon, naturalImage, owner);
		invincible = false;
		setMaxHealth(maxHealth);
		setHealth(health);
	}

	public AObject(int x, int y, Image miniIcon, Image naturalImage, APlayer owner) {
		this(x, y, 0, 0, miniIcon, naturalImage, owner);
	}

	public AObject(int x, int y, int width, int height, Image miniIcon, Image naturalImage, APlayer owner) {
		super(x, y, width, height);
		setOwner(owner);
		setBackground(Color.WHITE);
		setOpaque(false);
		this.miniIcon = miniIcon;
		this.naturalImage = naturalImage;
		invincible = true;//may be set again by other constructors
		statDispBox = new AStatusDisplayBox(this);
		//System.out.println("AO_INIT");
	}

	public AObject(APlayer owner) {
		this(0, 0, 0, 0, null, null, owner);
	}

	//=======================END=CONSTRUCTORS========================
    
	protected synchronized void dispose() {
		if (!disposed) {
			getAMP().remove(statDispBox);
			getAMP().remove(this);
			System.out.println("AO_DISPOSE");
			disposed = true;
		}
	}

	public void addSubPartsToAMP() {
		statDispBox.setVisible(false);
		getAMP().add(statDispBox);
		correctStatDispBoxPos();
	}
	
	public void updateSubPartsPosition() {
		correctStatDispBoxPos();
	}

	@Override
	public void setLocation(int x, int y) {
		super.setLocation(x, y);
		updateSubPartsPosition();
	}

	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g.create();
        //g2.rotate(Math.PI/2, getWidth()/2, getHeight()/2);
		g2.drawImage(naturalImage, 0, 0, this);
		g2.setColor(getDrawColour());
		if (paintCross) {
			g2.drawLine((getWidth() - AObject.CROSS_SIZE) / 2, getHeight() / 2, (getWidth() + AObject.CROSS_SIZE) / 2, (getHeight()) / 2);
			g2.drawLine(getWidth() / 2, (getHeight() - AObject.CROSS_SIZE) / 2, getWidth() / 2, (getHeight() + AObject.CROSS_SIZE) / 2);
		}
		//System.out.println("AO_PAINT");
	}

	private void setOwner(APlayer owner) {
		if (owner != null) {
			this.owner = owner;
		} else {
			System.out.println("owner specified was null. creating new owner (colour=black)");
			this.owner = new APlayer(Color.black);
		}
	}

	/**
	 * 
	 * @param newHealth
	 * @return true if dead
	 */
	private boolean setHealth(int newHealth) {
		if (newHealth > 0) {
			health = newHealth;
			correctStatDispBoxPos();
			return false;
		} else {
			health = 0;
			correctStatDispBoxPos();
			return true;
		}
	}

	private void setMaxHealth(int maxHealth) {
		this.maxHealth = maxHealth;
	}

	/**
	 * 
	 * @param amount
	 * @return true if the damage was successful
	 */
	protected boolean damage(int amount) {
		if (isAlive()) {
			if (setHealth(getHealth() - amount)) {
				kill();
			}
			return true;
		}
		return false;
	}

	public int getHealth() {
		return health;
	}

	public int getMaxHealth() {
		return maxHealth;
	}

	protected synchronized boolean kill() {
		if (alive) {
			alive = false;
			hideStatusBox();
			dispose();
			return true;
		}
		return false;
	}

	public APlayer getOwner() {
		return owner;
	}

	/**
	 * Starts at this instance's parent, checks if it is an instance of the GameArea class,
	 * if it is, returns it, if it's not checks the parent's parent and so on. If any parent is null returns null
	 * @return First instance of GameArea that is found when going up through this instance's lineage. If any parent is null returns null
	 */
	@Override
	public GameArea getAMP() {
		//TODO suround all getAMP() calls in null checks
		for (Container p = this; p != null; p = p.getParent()) {
			//System.out.println(p);
			if (p instanceof GameArea) {
				return (GameArea) p;
			}
		}
		return null;
	}

	/**
	 * Starts at this instance's parent, checks if it is an instance of the AGameViewer class,
	 * if it is, returns it, if it's not checks the parent's parent and so on. If any parent is null returns null
	 * @return First instance of AGameViewer that is found when going up through this instance's lineage. If any parent is null returns null
	 */
	public AGameViewer getAGV() {
		//TODO suround all getAGV() calls in null checks
		for (Container p = this; p != null; p = p.getParent()) {
			//System.out.println(p);
			if (p instanceof AGameViewer) {
				return (AGameViewer) p;
			}
		}
		return null;
	}

	/**
	 * simply a call to <code>getParent()</code> with a cast to AObject which you 
	 * probably would have had to do anyway. Purely for conviencence.
	 * @return <code>(AObject)(getParent());</code>
	 */
	public AObject getAOParent() {
		return (AObject) (getParent());
	}

	public Color getDrawColour() {
		return getOwner().getColour();
	}

	public void doNotPaintCross() {
		paintCross = false;
	}

	public void doPaintCross() {
		paintCross = true;
	}

	/**
	 * sets the <code>showStatus</code> flag to false and hides the status box
	 */
	public void doNotShowStatus() {
		showStatus = false;
		hideStatusBox();
	}

	/**
	 * sets the <code>showStatus</code> flag to true
	 */
	public void doShowStatus() {
		showStatus = true;
	}

	/**
	 * creates(if needed) and displays the status box if <code>showstatus</code> flag is set
	 * NOTE: this method is not to be confused with <code>doShowStatus()</code> which just sets the <code>showStatus</code> flag to true
	 */
	public void showStatusBox() {
		if (showStatus && statDispBox != null) {
			statDispBox.setVisible(true);
			correctStatDispBoxPos();
			statDispBox.repaint();
		}
		//System.out.println("AO_SHOW_STATUS"+showStatus+this);
	}

	/**
	 * hide the status box if <code>selected == false</code>
	 * NOTE: this method is not to be confused with <code>doNotShowStatus()</code>
	 * which just sets the <code>showStatus</code> flag to false
	 */
	public void hideStatusBox() {
		//System.out.println("selected = "+selected+" @hideStatusBox()");
		//the !isSelected is necessary-what if the mouse exits while this is selected?
		if (!selected && statDispBox != null) {
			statDispBox.setVisible(false);
		}
	}

	/**
	 * correct the position of the Status display box to the
	 * current location of this <code>AObject</code>
	 */
	public void correctStatDispBoxPos() {
		if (statDispBox != null && statDispBox.isVisible()) {
			statDispBox.correctPosition();
		}
	}

	/**
	 * selects fully/normally
	 * <p>
	 * function body: 
	 * <p>
	 *	select(false);
	 *  @see AObject#deselect(boolean)
	 */
	public void select() {
		select(false);
	}

	/**
	 * pseudo-selects
	 * <p>
	 * function body:
	 * <p>
	 *	deselect(true);
	 *  @see AObject#select(boolean)
	 */
	public void pseudoSelect() {
		select(true);
	}

	/**
	 * If not already selected, selects this <code>AObject</code>.
	 * If false is passed it selects it fully. But if true is
	 * passed this <code>AObject</code> only <i>thinks</i> it
	 * is selected (it is pseudo-selected). The AMP will not
	 * have it in its selection and its numSelected variable
	 * will not be affected. Note that this won't receive commands
	 * from the AMP.
	 * <p>
	 * selects by:<br>
	 * - selected = true;<br>
	 * - showing the status box
	 * @param pseudo weather or not to pseudo-select
	 */
	public void select(boolean pseudo) {
		//System.out.println(this+": selected = "+selected+" @select(boolean)");
		boolean success = true;//starting it true will cause this to do something still if pseudo == true.
		if (!selected) {
			if (!pseudo) {
				success = getAMP().addToSelection(this);
				//System.out.println("AO_SELECT");
			}//else{
			//System.out.println("AO_PSELECT");
			//}
			if (success) {
				selected = true;
				showStatusBox();
				//System.out.println("AO_SELECTED");
			}
		}
	}

	/**
	 * it is not advised to call this from the AMP because strange things may happen (this calls deselectAll()).
	 */
	public void selectOnlyThis() {
		getAMP().deselectAll();
		select();
	}

	/**
	 * deselects fully/normally
	 * function body: 
	 * <p>
	 *	deselect(false);
	 *  @see AObject#deselect(boolean)
	 */
	public void deselect() {
		deselect(false);
	}

	/**
	 * pseudo-deselects
	 * function body:
	 * <p>
	 *	deselect(true);
	 *  @see AObject#deselect(boolean)
	 */
	public void deselectPseudo() {
		deselect(true);
	}

	/**
	 * If not already deselected, deselects this <code>AObject</code>. If false is passed it deselects it fully.
	 * but if true is passed this <code>AObject</code> only <i>thinks</i> it
	 * is deselected (it is pseudo-deselected). The AMP still has it in its selection and its numSelected
	 * variable is not affected. Note that this still could receive commands from the AMP.
	 * <p>
	 * deselects by:<br>
	 * - selected = false;<br>
	 * - hiding the status box
	 * @param pseudo weather or not to pseudo-deselect
	 */
	public void deselect(boolean pseudo) {
		if (selected) {
			if (!pseudo) {
				getAMP().removeFromSelection(this);
				//System.out.println(getClass()+" AO_DESELECT");
			}//else{
			//System.out.println(getClass()+" AO_PDESELECT");
			//}
			selected = false;
			hideStatusBox();
		}
	}

	public boolean isSelected() {
		return selected;
	}

	public ObjectResourceHolder getSrc() {
		return src;
	}

	public boolean isAlive() {
		return alive;
	}

	public boolean isDisposed() {
		return disposed;
	}

	@Override
	public String toString() {
		return (getSrc() != null ? getSrc().getQualifiedName() : getClass().getSimpleName()) + ", x = " + getX() + ", y = " + getY() + ", w = " + getWidth() + ", h = " + getHeight();
	}

	//====================Mouse Listeners========================
	@Override
	public void mouseClicked(MouseEvent e) {
		//System.out.println("AO_M_CLICKED");
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getClickCount() == 2) {
			System.out.println(this);
		} else {
			if (e.getButton() == MouseEvent.BUTTON1) {
				if (e.isShiftDown()) {
					select();
					//System.out.println(this+" was Shift-Selected\n");
				} else if (e.isControlDown()) {
					deselect();
					//System.out.println(this+" was Ctrl-Deselected\n");
				} else {
					selectOnlyThis();
					//System.out.println(this+" was Only-Selected\n");
				}
			} else if (!isSelected() && ((e.getButton() == MouseEvent.BUTTON3) || (e.getButton() == MouseEvent.BUTTON2))) {
				System.out.println(this + " received a targetive mousepress while not selected (button " + e.getButton() + "). Notifying AMP");
				getAMP().notifyOfTargetiveMousePress(this);
			} else {
				getAMP().notifyOfMousePress(this, e);
			}
		}
		//System.out.println("AO_PRESSED");
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		//System.out.println("AO_M_RELEASED");
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		showStatusBox();
		//System.out.println("AO_M_ENTERED");
	}

	@Override
	public void mouseExited(MouseEvent e) {
		hideStatusBox();
		//System.out.println("AO_M_EXITED");
	}
}
