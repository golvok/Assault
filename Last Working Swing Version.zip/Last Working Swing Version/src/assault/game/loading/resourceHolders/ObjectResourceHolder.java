/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.loading.resourceHolders;

import assault.game.loading.ResourcePreloader;
import assault.game.APlayer;
import assault.game.display.ACommandButton;
import assault.game.gameObjects.AObject;
import assault.game.util.commands.ACommand;
import assault.game.util.commands.CreateCmd;
import assault.game.util.commands.MoveCmd;
import java.awt.Color;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.awt.image.LookupOp;
import java.awt.image.LookupTable;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import org.jdom.DataConversionException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 * override pareXML() NOT load() and call super.parseXmlValues() in first line
 * @author matt
 */
public class ObjectResourceHolder extends ResourceHolder {

	public static final String IMAGE_FOLDER_NAME = "images";
	public static final String MINI_ICON_FOLDER_NAME = "miniIcons";
	public static String TYPE_NAME = "Object";
	protected ModResourceHolder mod;
	protected SAXBuilder builder;
	protected Document xml;
	protected Element rootE;
	private String name;
	private int width;
	private int height;
	private int maxHealth;
	private ACommandButton[] cmdBtns;
	private BufferedImage miniIcon;
	private String[] speedNames = {};
	private int[] speeds = {};
	private BufferedImage naturalImage;

	public ObjectResourceHolder(ModResourceHolder mod, File xmlFile, ResourcePreloader rp, SAXBuilder sb) throws BadlyFormattedXMLException, ResourceHolderException {
		super(rp, xmlFile);
		builder = sb;
		this.mod = mod;
		//temporary name assignment
		name = xmlFile.getName().substring(0, xmlFile.getName().length() - 4);//removes ".xml"
	}

	/**
	 * Builds parses the baseFile for AObject values but also 
	 * sets the rootE to the root Element. if this is not called,
	 * xml and rootE WILL REMAIN NULL so ALWAYS call this from a 
	 * override of this method.
	 * @throws BadlyFormattedXMLException
	 * @throws ResourceHolderException 
	 */
	@SuppressWarnings("unchecked")
	protected void parseXmlValues() throws BadlyFormattedXMLException, ResourceHolderException {
		try {
			rp.setStatusString("\nloading Object values in " + baseFile);
			xml = builder.build(baseFile);//basefile is set in superclass
			rootE = xml.getRootElement();

			//simple values
			width = rootE.getChild("dims").getAttribute("width").getIntValue();
			height = rootE.getChild("dims").getAttribute("height").getIntValue();
			maxHealth = rootE.getChild("health").getAttribute("max").getIntValue();

			//name
			String foundName = rootE.getChildText("name");
			if (!(foundName + ".xml").equals(baseFile.getName())) {
				rp.addError("the name found in the file (" + foundName + ") differs from file name(" + baseFile.getName() + ").");
				throw new BadlyFormattedXMLException("name in file is diffenent");
			}
			name = foundName;

			//miniIcon
			File miniIconFile = new File(baseFile.getParent(), rootE.getChild("miniIcon").getAttributeValue("src"));
			rp.setStatusString("\tmini icon path = " + miniIconFile);
			if (checkAccess(miniIconFile)) {
				miniIcon = ImageIO.read(miniIconFile);
				rp.setStatusString("\tO.K. good image");
			} else {
				rp.addError("there is no image (or it's inaccessable) at " + miniIconFile);
				miniIcon = null;
			}

			//natural image
			File baseImageFile = new File(baseFile.getParent(), rootE.getChild("img").getChild("base").getAttributeValue("src"));
			rp.setStatusString("\tnatural image path = " + baseImageFile);
			if (checkAccess(baseImageFile)) {
				naturalImage = ImageIO.read(baseImageFile);
				rp.setStatusString("\tO.K. good image");
			} else {
				rp.addError("there is no image (or it's inaccessable) at " + baseImageFile);
				naturalImage = null;
			}

			//speeds
			Element speedsElement = rootE.getChild("speeds");
			if (rootE.getChild("noSpeeds") == null || speedsElement != null) {
				List<Element> speedElements = speedsElement.getChildren();
				int numSpeeds = speedElements.size();
				speedNames = new String[numSpeeds];
				speeds = new int[numSpeeds];
				for (int i = 0; i < numSpeeds; i++) {
					Element speed = speedElements.get(i);
					speedNames[i] = speed.getName();
					speeds[i] = speed.getAttribute("val").getIntValue();
				}
			}/*else{
			//the arrays are allready initialized to 0 length arrays
			}*/

			rp.setStatusString("loaded object values in " + baseFile);

		} catch (DataConversionException ex) {
			throw new BadlyFormattedXMLException(getQualifiedName(),
					"bad data in " + baseFile + " (something cant be converted from a string properly) Message: " + ex.getStackTrace()[0]);
		} catch (NullPointerException ex) {
			throw new BadlyFormattedXMLException(getQualifiedName(),
					((rootE == null) ? ("Root element in " + baseFile + " was null") : (baseFile + " is improperly formated (something's missing or named wrong)")) + "\n\tMessage: " + ex.getStackTrace()[0]);
		} catch (JDOMException ex) {
			throw new ResourceHolderException(getQualifiedName(),
					"problem parsing AObject. Message: " + ex.getMessage());
		} catch (IOException ex) {
			throw new ResourceHolderException(getQualifiedName(),
					"I/O error during build. (src: " + baseFile + "):\n" + ex.toString());
		}
	}

	protected ACommandButton parseXmlButton(Element xmlBtn) throws BadlyFormattedXMLException {
		String cmdType;
		Element cmdE;
		ACommand cmd = null;
		UnitResourceHolder unit = null;
		//TODO add functionality for complex commands
		try {
			cmdE = xmlBtn.getChild("action").getChild("command");
			cmdType = cmdE.getAttributeValue("type");
			if (cmdType.equals("Move")) {
				cmd = new MoveCmd(rp);
			} else if (cmdType.equals("Create")) {
				Element unitTypeE = cmdE.getChild("unitType");
				char hotkey = cmdE.getChildText("hotKey").charAt(0);
				String modName = unitTypeE.getAttributeValue("mod");
				String unitName = unitTypeE.getAttributeValue("name");
				try {
					unit = rp.getModUnitByName(modName, unitName);
				} catch (ResourceHolderException ex) {
					throw new BadlyFormattedXMLException(getQualifiedName(), "a button element references something wrong. Message:\n" + ex.getReason() + " Can't create Create Button");
				}
				//getModUnit allways throws an exception on failure
				cmd = new CreateCmd(cmdE.getChildText("name"), hotkey, unit);
			} else {
				throw new BadlyFormattedXMLException("unrecognised command : " + cmdType);
			}
		} catch (NullPointerException ex) {
			throw new BadlyFormattedXMLException(getQualifiedName(),
					"a button element is improperly formated (something's missing or named wrong)" + (unit != null ? " or there is something wrong (missing?) in " + unit.getQualifiedName() : "") + " Message: " + ex.getStackTrace()[0]);
		}
		if (cmd != null) {
			return new ACommandButton(cmd);
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private void parseXmlButtons() throws BadlyFormattedXMLException {
		try {
			Element[] xmlBtns = {};
			xmlBtns = (Element[]) rootE.getChild("buttons").getChildren("button").toArray(xmlBtns);
			cmdBtns = new ACommandButton[xmlBtns.length];
			for (int i = 0; i < xmlBtns.length; i++) {
				try {
					cmdBtns[i] = parseXmlButton(xmlBtns[i]);
				} catch (BadlyFormattedXMLException e) {
					rp.addError(e);
				}
			}
		} catch (NullPointerException ex) {
			throw new BadlyFormattedXMLException(getQualifiedName(),
					((rootE == null) ? ("Root element in " + baseFile + " was null") : (baseFile + " is improperly formated (something's missing or named wrong)")) + "\n\tMessage: " + ex.getStackTrace()[0]);
		}
	}

	@Override
	public synchronized void load() throws ResourceHolderException {
		if (!loaded) {
			loading = true;
			parseXmlValues();
			loading = false;
			loaded = true;
		}
	}

	@Override
	public synchronized void loadReferencial() throws ResourceHolderException {
		if (!loadedReferencial && loaded) {
			loadingReferencial = true;
			parseXmlButtons();
			loadingReferencial = false;
			loadedReferencial = true;
		}
	}

	public AObject createObject(int x, int y, APlayer owner) throws ResourceHolderException{
		return new AObject(x, y, this, owner);
	}

	public AObject createObject(Point p, APlayer owner) throws ResourceHolderException{
		return createObject(p.x, p.y, owner);
	}

	public Document getXml() {
		return new Document(xml.getRootElement());
	}

	public String getName() {
		return name;
	}

	public String getQualifiedName() {
		String out = "";
		if (mod == null || mod.getName() == null) {
			out += "???.";
		} else {
			out += mod.getName() + ".";
		}
		if (getName() == null) {
			if (baseFile != null) {
				out += baseFile.toString();
			} else {
				out += "???";
			}
		} else {
			out += getName();
		}
		return out;
	}

	public int getHeight() {
		return height;
	}

	public int getWidth() {
		return width;
	}

	public int getMaxHealth() {
		return maxHealth;
	}

	public ACommandButton[] getCmdBtns() {
		ACommandButton[] temp = new ACommandButton[cmdBtns.length];
		System.arraycopy(cmdBtns, 0, temp, 0, cmdBtns.length);
		return temp;
	}

	public BufferedImage getMiniIcon() {
		return miniIcon;
	}

	public BufferedImage getBaseImage(APlayer player) {
		return filterImageForPlayerColour(naturalImage, player);
	}
	private static Map<BufferedImage, Map<APlayer, BufferedImage>> allreadyFiltered = Collections.synchronizedMap(new HashMap<BufferedImage, Map<APlayer, BufferedImage>>(40));

	/**
	 * replaces the transparent black pixels in <code>img</code> with
	 * <code>player.getColour()</code>. filtered images
	 * are stored in a <code>Map</code> for reuse if the same image and
	 * player are requested again.
	 * 
	 * @param img image to filter
	 * @param player who's colour or pre-filtered images to use
	 * @return the filtered image
	 */
	private static BufferedImage filterImageForPlayerColour(BufferedImage img, final APlayer player) {

		//check if and retieve allready filtered images
		Map<APlayer, BufferedImage> ApToBMap = (Map<APlayer, BufferedImage>) allreadyFiltered.get(img);
		if (ApToBMap != null) {
			BufferedImage biInMap = (BufferedImage) ApToBMap.get(player);
			if (biInMap != null) {
				//System.out.println("allready filtered");
				return biInMap;
			}
		}
		//System.out.println("needs filtering");

		//the colour to replace
		final Color replC = new Color(0x00, 0x00, 0xfe, 0xff);//almost blue

		//replace the pixels
		BufferedImage out = new LookupOp(new LookupTable(0, 4) {

			@Override
			public int[] lookupPixel(int[] src, int[] dest) {
				if (src.length == 4) {
					if (src[0] == replC.getRed() && src[1] == replC.getGreen() && src[2] == replC.getBlue() && src[3] == replC.getAlpha()) {
						if (dest == null) {
							dest = new int[4];
						}
						Color c = player.getColour();
						dest[0] = c.getRed();
						dest[1] = c.getGreen();
						dest[2] = c.getBlue();
						dest[3] = c.getAlpha();
						//System.out.println("changed a Pixel");
						return dest;
					}// else {
					//return src;
					//}
				}// else {
				//System.out.println("wrong length l = " + src.length);
				return src;
				//}
			}
		}, null).filter(img, null);

		//add the filtered image to the map (uses the same <APlayer, BufferedImage> Map retrieved before)
		if (ApToBMap == null) {
			//the case where the <APlayer, BufferedImage> map needs to be added
			ApToBMap = Collections.synchronizedMap(new HashMap<APlayer, BufferedImage>(8));
			allreadyFiltered.put(img, ApToBMap);
		}
		ApToBMap.put(player, out);

		return out;
	}

	/**
	 * -1 if speed doesn't exist
	 * @param type
	 * @return 
	 */
	public int getSpeed(String type) {
		for (int i = 0; i < speedNames.length; i++) {
			if (speedNames[i].equals(type)) {
				return speeds[i];
			}
		}
		return -1;
	}

	public String[] getSpeedNames() {
		String[] temp = new String[speedNames.length];
		System.arraycopy(speedNames, 0, temp, 0, speedNames.length);
		return temp;
	}

	public int[] getSpeeds() {
		int[] temp = new int[speeds.length];
		System.arraycopy(speeds, 0, temp, 0, speeds.length);
		return temp;
	}

	public String getTypeName() {
		return TYPE_NAME;
	}
}
