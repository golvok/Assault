/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game.util;

import assault.game.display.GameArea;
import java.awt.Rectangle;

/**
 *
 * @author matt
 */
public interface GridObject {
	public int getX();
	public int getY();
	public int getWidth();
	public int getHeight();
	public GameArea getAMP();

    public Rectangle getBounds();
}
