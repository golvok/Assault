/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.loading.resourceHolders;

import assault.game.loading.ResourcePreloader;
import assault.game.APlayer;
import assault.game.display.ACommandButton;
import assault.game.gameObjects.AUnit;
import assault.game.util.commands.ACommand;
import assault.game.util.commands.ShootCommand;
import java.awt.Point;
import java.io.File;
import org.jdom.DataConversionException;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author matt
 */
public class UnitResourceHolder extends ObjectResourceHolder {

	public static final String UNIT_TYPE_NAME = "Unit";
	private Point CreatePoint;
	private Point[] mountPts = {};
	private WeaponResourceHolder[] weapons = {};

	/**
	 *
	 * @param mod it's parent mod
	 * @param xml it's name
	 * @param rp it's parent resourcePreloader
	 * @param builder a SAXbuilder to use
	 */
	public UnitResourceHolder(ModResourceHolder mod, File xmlFile, ResourcePreloader rp, SAXBuilder builder) throws ResourceHolderException {
		super(mod, xmlFile, rp, builder);
		rp.setStatusString("created unit at " + baseFile);
	}

	@Override
	@SuppressWarnings("unchecked")
	protected void parseXmlValues() throws BadlyFormattedXMLException, ResourceHolderException {
		super.parseXmlValues();
		rp.setStatusString("loading the unit values in " + baseFile);
		try {
			//create Point
			Element cpElement = rootE.getChild("createPoint");
			CreatePoint = new Point(cpElement.getAttribute("x").getIntValue(), cpElement.getAttribute("y").getIntValue());

			//mount points
			Element[] mntPtsElements = {};
			mntPtsElements = (Element[]) rootE.getChild("mountPoints").getChildren("p").toArray(mntPtsElements);
			int higestMPINdex = 0;
			int mpIndex;
			for (int i = 0; i < mntPtsElements.length; i++) {
				mpIndex = mntPtsElements[i].getAttribute("i").getIntValue();
				if (mpIndex > higestMPINdex) {
					higestMPINdex = mpIndex;
				} else if (mpIndex < 0) {
					mntPtsElements[i] = null;
					rp.addError("The mountpoint with a negative index in " + getQualifiedName() + " was ignored");
				}
			}
			mountPts = new Point[higestMPINdex + 1];
			for (int i = 0; i < mntPtsElements.length; i++) {
				//no need for bounds checking, allready done
				mountPts[mntPtsElements[i].getAttribute("i").getIntValue()] = new Point(mntPtsElements[i].getAttribute("x").getIntValue(), mntPtsElements[i].getAttribute("y").getIntValue());
			}

			//weapons
			if (rootE.getChild("noWeapons") == null) {
				Element[] weaponElements = {};
				weaponElements = (Element[]) rootE.getChild("weapons").getChildren("weapon").toArray(weaponElements);
				weapons = new WeaponResourceHolder[mountPts.length];
				String weaponName;
				String modName;
				int mountPointIndex;
				for (int i = 0; i < weaponElements.length; i++) {
					mountPointIndex = weaponElements[i].getAttribute("mountpoint").getIntValue();
					weaponName = weaponElements[i].getAttributeValue("name");
					modName = weaponElements[i].getAttributeValue("mod");
					if (mountPointIndex >= 0 && mountPointIndex < mountPts.length) {
						try {
							weapons[mountPointIndex] = rp.getModWeaponByName(modName, weaponName);
						} catch (ResourceHolderException e) {
							rp.addError(getQualifiedName() + " tried to add a " + modName + "." + weaponName + " weapon, which doesn't exist Message:\n\t" + e);
						}
					} else {
						rp.addError(getQualifiedName() + " tried to add a " + modName + "." + weaponName + " weapon to the invalid (OOBounds or null) mountpoint index, " + mountPointIndex);
					}
				}
			}
		} catch (DataConversionException ex) {
			rp.addError("bad data in " + baseFile + " (something cant be converted from a string properly) Message: " + ex.getStackTrace()[0]);
			throw new BadlyFormattedXMLException(getQualifiedName(), ex);
		} catch (NullPointerException ex) {
			rp.addError(((rootE == null) ? ("Root element in " + baseFile + " was null") : (baseFile + " is improperly formated (something's missing or named or referenced wrong)")) + "\n\tMessage: " + ex.getStackTrace()[0]);
			throw new BadlyFormattedXMLException(getQualifiedName(), ex);
		}
		rp.setStatusString("loaded unit values in " + baseFile);
	}

	@Override
	protected ACommandButton parseXmlButton(Element xmlBtn) throws BadlyFormattedXMLException {
		BadlyFormattedXMLException superException = null;
		try {
			ACommandButton superB = super.parseXmlButton(xmlBtn);
			if (superB != null) {
				return superB;
			}
		} catch (BadlyFormattedXMLException e) {
			superException = e;
			//continue normally, try to parse it with this method
		}
		String cmdType;
		Element cmdE;
		ACommand cmd = null;
		//TODO add functionality for complex commands
		try {
			cmdE = xmlBtn.getChild("action").getChild("command");
			cmdType = cmdE.getAttributeValue("type");
			if (cmdType.equals("Shoot")) {
				char hotkey = cmdE.getChildText("hotKey").charAt(0);
				int mountPoint = cmdE.getChild("mountPoint").getAttribute("val").getIntValue();
				if (mountPoint < 0) {
					throw new BadlyFormattedXMLException("the specified mountpoint for a button in " + getQualifiedName() + "(" + mountPoint + ") is negative");
				}
				cmd = new ShootCommand(cmdE.getChildText("name"), rp, hotkey, mountPoint);
			} else {
				if (superException != null && cmdType.equals("Create")) {
					throw superException;
				} else {
					throw new BadlyFormattedXMLException("unrecognised command : " + cmdType);
				}
			}
		} catch (DataConversionException ex) {
			throw new BadlyFormattedXMLException("could not convert from a string properly int");
		} catch (NullPointerException ex) {
			if (xmlBtn == null) {
				throw new BadlyFormattedXMLException("a xmlButton supplied was null");
			} else if (xmlBtn.getChild("action") == null) {
				throw new BadlyFormattedXMLException("an \"action\" element in a supplied xmlButton was null");
			} else if (xmlBtn.getChild("action").getChild("command") == null) {
				throw new BadlyFormattedXMLException("a \"command\" element in a supplied xmlButton was null");
			} else if (xmlBtn.getChild("action").getChild("command").getChildText("name") == null) {
				throw new BadlyFormattedXMLException("a \"name\" element in a supplied xmlButton was null");
			} else {
				throw new BadlyFormattedXMLException("a xmlButton supplied was improperly formatted Message : " + ex.getStackTrace()[0]);
			}
		}
		if (cmd != null) {
			return new ACommandButton(cmd);
		} else {
			return null;
		}
	}

	@Override
	public AUnit createObject(int x, int y, APlayer owner) {
		try {
			return new AUnit(x, y, this, owner);
		} catch (ResourceHolderException ex) {
			rp.addError(ex);
			return null;
		}
	}

	@Override
	public AUnit createObject(Point p, APlayer owner) {
		return createObject(p.x, p.y, owner);
	}

	/**
	 * remember this point is a <i>relative<i/> point
	 * @return 
	 */
	public Point getCreatePoint() {
		return new Point(CreatePoint);
	}

	public Point[] getMountPoints() {
		Point[] temp = new Point[mountPts.length];
		for (int i = 0; i < temp.length; i++) {
			if (mountPts[i] != null) {
				temp[i] = new Point(mountPts[i]);
			} else {
				temp[i] = null;
			}
		}
		return temp;
	}

	public WeaponResourceHolder[] getWeapons() {
		WeaponResourceHolder[] temp = new WeaponResourceHolder[weapons.length];
		System.arraycopy(weapons, 0, temp, 0, weapons.length);
		return temp;
	}
}
