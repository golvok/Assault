/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game.util.commands;

/**
 *
 * @author matt
 */
public interface NormalCommand {
	public void execute();
}
