/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.util.pathfinding;

import assault.game.util.GridManager;
import assault.game.util.GridObject;

/**
 *
 * @author 088241930
 */
public abstract class PathFinder {

    protected final GridManager gManager;
      
    public PathFinder(GridManager gm) {
        gManager = gm;
    }
    public abstract PathObject findPath(PathFindingGridObject pfgo, int destX, int destY);
}
