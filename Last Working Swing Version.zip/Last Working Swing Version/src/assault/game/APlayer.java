/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game;

import java.awt.Color;

/**
 *
 * @author matt
 */
public class APlayer {
	private Color colour;
	public APlayer(Color colour) {
		super();
		this.colour = colour;
	}
	public Color getColour() {
		return colour;
	}
}
