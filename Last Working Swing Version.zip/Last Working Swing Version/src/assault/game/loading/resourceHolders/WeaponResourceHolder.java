/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.loading.resourceHolders;

import assault.game.loading.ResourcePreloader;
import assault.game.APlayer;
import assault.game.gameObjects.AWeapon;
import java.awt.Point;
import java.io.File;
import org.jdom.DataConversionException;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author 088241930
 */
public class WeaponResourceHolder extends ObjectResourceHolder {

	final static String WEAPON_TYPE_NAME = "Weapon";
	private int bulletSize;
	private boolean projectile;
	private int rotatePointX;
	private int rotatePointY;

	public WeaponResourceHolder(ModResourceHolder mod, File xmlFile, ResourcePreloader rp, SAXBuilder builder) throws BadlyFormattedXMLException, ResourceHolderException {
		super(mod,  xmlFile, rp, builder);
	}

	@Override
	public void parseXmlValues() throws BadlyFormattedXMLException, ResourceHolderException{
		super.parseXmlValues();
		rp.setStatusString("loading weapon values in "+baseFile);
		try {
			//rotation point
			Element rpe = rootE.getChild("rotatePoint");
			rotatePointX = rpe.getAttribute("x").getIntValue();
			rotatePointY = rpe.getAttribute("y").getIntValue();
			
			//projectile
			projectile = rootE.getChild("projectile").getAttribute("val").getBooleanValue();
			
			//size
			bulletSize = rootE.getChild("size").getAttribute("val").getIntValue();
		} catch (DataConversionException ex) {
			rp.addError("bad data in " + baseFile + " (something cant be converted from a string properly) Message: " + ex.getStackTrace()[0]);
			throw new BadlyFormattedXMLException(getQualifiedName(),ex);
		} catch (NullPointerException ex) {
			rp.addError("XML " + ((xml == null) ? "file was null" : ("in " + baseFile + " is improperly formated (something's missing or named wrong)\n\tMessage: " + ex.getStackTrace()[0])));
			throw new BadlyFormattedXMLException(getQualifiedName(),ex);
		}
		rp.setStatusString("loaded weapon values in " + baseFile);
	}

	@Override
	public AWeapon createObject(int x, int y, APlayer owner) throws ResourceHolderException {
		return new AWeapon(x, y, this, owner);
	}

	@Override
	public AWeapon createObject(Point p, APlayer owner) throws ResourceHolderException {
		return createObject(p.x, p.y, owner);
	}

	public int getBulletSize() {
		return bulletSize;
	}

	public boolean isProjectile() {
		return projectile;
	}

	public int getRotatePointX() {
		return rotatePointX;
	}

	public int getRotatePointY() {
		return rotatePointY;
	}
}
