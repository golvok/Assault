/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.loading.resourceHolders;

import assault.game.loading.ResourcePreloader;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author matt
 */
public class ModResourceHolder extends ResourceHolder {

	public static final String UNIT_FILE_NAME = "Unit";
	public static final String WEAPON_FILE_NAME = "Weapon";
	public static final String INFO_FILE_NAME = "modinfo.xml";
	public static final String INFO_FILE_NAME_TAG_NAME = "name";
	public static final String INFO_FILE_HAS_UNITS_TAG_NAME = "hasUnits";
	public static final String INFO_FILE_HAS_BUILDINGS_TAG_NAME = "hasBuildings";
	public static final String INFO_FILE_HAS_WEAPONS_TAG_NAME = "hasWeapons";
	public static final String INFO_FILE_HAS_TERRAIN_OBJECTS_TAG_NAME = "hasTerrainObjects";
	private SAXBuilder builder;
	private Element infoFileRoot;
	private String name = "";
	private boolean hasUnits = false;
	private boolean hasWeapons = false;
	//private boolean hasBuildings = false;
	//private boolean hasTerrainObjects = false;
	private UnitResourceHolder[] units = {};
	private WeaponResourceHolder[] weapons = {};
	//private BuildingResourceHolder[] buildings = {};
	//private TerrainObjectResourceHolder[] terrainObjects = {};

	/**
	 *
	 * @param name name of the folder in src/mods/ to look in
	 */
	public ModResourceHolder(String name, ResourcePreloader rp, SAXBuilder builder) throws ResourceHolderException {
		super(rp, "mods/" + name);
		this.name = name;
		this.builder = builder;
		rp.setStatusString("created mod named " + name);
	}

	@Override
	public synchronized void load() throws ResourceHolderException {
		if (!loaded) {
			//parse the infofile
			try {
				System.out.println("mod path = " + baseFile.getAbsolutePath());
				String infoPath = baseFile.getAbsolutePath() + "/" + INFO_FILE_NAME;
				System.out.println("mod infoFile path = " + infoPath);
				infoFileRoot = builder.build(new File(infoPath)).getRootElement();
				if (infoFileRoot.getChild(ModResourceHolder.INFO_FILE_NAME_TAG_NAME) != null) {
					String name2 = infoFileRoot.getChild(ModResourceHolder.INFO_FILE_NAME_TAG_NAME).getText();
					System.out.println("mod name (in info file) = " + name2);
				} else {
					rp.setStatusString("name for mod at " + name + " wasn't in info file -- continuing with name of folder");
				}
				if (infoFileRoot.getChild(ModResourceHolder.INFO_FILE_HAS_UNITS_TAG_NAME) != null) {
					hasUnits = true;
				}
				if (infoFileRoot.getChild(ModResourceHolder.INFO_FILE_HAS_WEAPONS_TAG_NAME) != null) {
					hasWeapons = true;
				}
			} catch (NullPointerException ex) {
				rp.addError(((infoFileRoot == null) ? ("Root element in " + baseFile + " was null") : (baseFile + " is improperly formated (something's missing or named wrong)")) + "\n\tMessage: " + ex.getStackTrace()[0]);
				throw new ResourceHolderException(getName(), ex);
			} catch (JDOMException ex) {
				rp.addError("problem parsing mod info file for mod in " + name + " folder");
				throw new ResourceHolderException(getName(), ex);
			} catch (IOException ex) {
				rp.addError("I/O problem reading mod info file for mod in " + name + " folder\n" + ex.toString());
				throw new ResourceHolderException(getName(), ex);
			}
			//create this mod's contents
			createResourceHolders();
			loaded = true;
		}
	}

	private void loadAObjects() {
		//units
		loadAObjects(units);
		//weapons
		loadAObjects(weapons);
	}

	@Override
	public void loadReferencial() throws ResourceHolderException {
		if (!loadedReferencial) {
			loadingReferencial = true;
			loadAObjects();
			loadingReferencial = false;
			loadedReferencial = true;
		}
	}

	private void loadAObjects(ObjectResourceHolder[] ors) {
		for (int i = 0; i < ors.length; i++) {
			if (ors[i] != null) {
				try {
					ors[i].load();
				} catch (ResourceHolderException ex) {
					rp.addError("Did not load " + ors[i].getQualifiedName() + ": \n\t" + ex);
					ors[i].setValid(false);//it's false by deafult, buttttt...
					ors[i] = null;
				}
			}
		}
		for (int i = 0; i < ors.length; i++) {
			if (ors[i] != null) {
				try {
					ors[i].loadReferencial();
					ors[i].setValid(true);
				} catch (ResourceHolderException ex) {
					rp.addError("Did not load " + ors[i].getQualifiedName() + ": \n\t" + ex);
					ors[i].setValid(false);//it's false by deafult, buttttt...
					ors[i] = null;
				}
			}
		}
	}

	private void createResourceHolders() {
		if (hasUnits) {
			units = (UnitResourceHolder[]) createObjectResourceHolder(UNIT_FILE_NAME);
		}
		if (hasWeapons) {
			weapons = (WeaponResourceHolder[]) createObjectResourceHolder(WEAPON_FILE_NAME);
		}
	}

	private ObjectResourceHolder[] createObjectResourceHolder(String typeName) {
		if (!(typeName.equals(UNIT_FILE_NAME) || typeName.equals(WEAPON_FILE_NAME))) {
			//not one of the typenames allowed.
			return null;
		}
		if (!loaded) {
			ObjectResourceHolder[] arrayOut = null;

			//get all the .xml files in the directory
			rp.setStatusString("finding " + typeName + " xml files for " + getName() + "looking at ...");
			File[] objectFiles = new File(baseFile, typeName).listFiles(new FilenameFilter() {

				@Override
				public boolean accept(File dir, String name) {
					System.out.println("\t" + dir + "/" + name);
					return name.endsWith(".xml");
				}
			});
			if (typeName.equals(UNIT_FILE_NAME)) {
				arrayOut = new UnitResourceHolder[objectFiles.length];
			} else if (typeName.equals(WEAPON_FILE_NAME)) {
				arrayOut = new WeaponResourceHolder[objectFiles.length];
			}
			int j = 0;
			for (int i = 0; i < objectFiles.length; i++) {
				rp.setStatusString("creating a " + typeName + " from xml. using ...");
				File xmlFile = objectFiles[i];
				rp.setStatusString(xmlFile.getAbsolutePath());
				//System.out.println("checking existance of " + xmlLoc);
				//if (!xmlLoc.exists()){
				//System.out.println("                      " + xmlLoc + " exists!");
				try {
					if (typeName.equals(UNIT_FILE_NAME)) {
						arrayOut[j] = new UnitResourceHolder(this, xmlFile, rp, rp.getBuilder());
					} else if (typeName.equals(WEAPON_FILE_NAME)) {
						arrayOut[j] = new WeaponResourceHolder(this, xmlFile, rp, rp.getBuilder());
					}
					j++;
					rp.setStatusString("Created " + typeName);
				} catch (ResourceHolderException e) {
					rp.addError("Did not create " + typeName + "!");
				}
				//}else{
				//	System.out.println("too bad");
				//}
				System.out.println();
			}
			return arrayOut;
		}
		return null;
	}

	public String getPath() {
		return baseFile.getAbsolutePath();
	}

	public UnitResourceHolder getUnitByName(String unitName) {
		for (int i = 0; i < units.length; i++) {
			if (units[i] != null && units[i].getName() != null && units[i].getName().equals(unitName)) {
				return units[i];
			}
		}
		return null;
	}

	public WeaponResourceHolder getWeaponByName(String weaponName) {
		for (int i = 0; i < weapons.length; i++) {
			if (weapons[i] != null && weaponName.equals(weapons[i].getName())) {
				return weapons[i];
			}
		}
		return null;
	}

	public String getName() {
		return name;
	}

	public boolean hasUnits() {
		return hasUnits;
	}

	public UnitResourceHolder[] getUnits() {
		return units;
	}
}
