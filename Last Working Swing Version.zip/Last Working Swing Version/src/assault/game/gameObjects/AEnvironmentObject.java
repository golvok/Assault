/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game.gameObjects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;

/**
 *part of the terrain that can be interacted with (destroyed, created, selected ect.)
 * @author matt
 */
public final class AEnvironmentObject extends AObject{

	private Polygon shape = null;
	public AEnvironmentObject(int x,int y,Point[] shape,Image miniIcon){
		super(x, y, miniIcon,null,null);
		setLocation(x, y);
		int[] xPoints = new int[shape.length];
		int[] yPoints = new int[shape.length];
		for(int i = 0;i<shape.length;i++){
			xPoints[i] = shape[i].x;
			yPoints[i] = shape[i].y;
		}
		this.shape = new Polygon(xPoints,yPoints,xPoints.length);
		
		Rectangle bounds = this.shape.getBounds();
		setSize(bounds.width+1, bounds.height+1);
	}
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		Graphics g2 = g.create();
		g2.setColor(Color.gray);
		g2.drawPolygon(shape);
		g2.drawString("E", getWidth()/2, getHeight()/2);
		//System.out.println("EO_PAINT");
	}
}
