/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.gameObjects;

//import assault.objects.AObject;
//import assault.objects.AUnit;
import assault.game.APlayer;
import assault.game.display.ACommandDispatchMenu;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.lwjgl.opengl.GL11;

/**
 *
 * @author matt
 */
public class AGroup extends AUnit {

	private List<AUnit> units = Collections.synchronizedList(new ArrayList<AUnit>(5));
	private boolean drawBox = false;

	public AGroup(AUnit[] startUnits, APlayer owner) {
		super(owner);
		addUnits(startUnits);
		doNotShowStatus();
		doNotPaintCross();
		setCmdBtnSet(ACommandDispatchMenu.getUniqueCmdBtnSet(units));
		resizeToUnits();
	}

	public void addUnit(AUnit newUnit) {
		units.add(newUnit);
		newUnit.registerGroup(this);
		resizeToUnits();
		setCmdBtnSet(ACommandDispatchMenu.getUniqueCmdBtnSet(units));
	}

	public void addUnits(AUnit[] newUnits) {
		for (int i = 0; i < newUnits.length; i++) {
			if (newUnits[i] != null) {
				units.add(newUnits[i]);
				newUnits[i].registerGroup(this);
			}
		}
		resizeToUnits();
		setCmdBtnSet(ACommandDispatchMenu.getUniqueCmdBtnSet(units));
	}

	public void removeUnit(AUnit au) {
		units.remove(au);
		resizeToUnits();
	}

	public void removeUnits(AUnit[] aus) {
		for (int i = 0; i < aus.length; i++) {
			removeUnit(aus[i]);
		}
	}

	@Override
	public void shootBulletAt(AObject target, AWeapon aw) {
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			AUnit aUnit = it.next();
			if (aUnit != null) {
				aUnit.shootBulletAt(target, aw);
			}
		}
	}

	/**
	 * using <code>setBounds()</code> adjust the X ,Y, width and Height so that
	 * this fits over the <code>AUnits</code> in <code>units</code>.
	 */
	public void resizeToUnits() {
		int GAP_SIZE = 10;
		int newWidth = 0;//<---ends up being min size
		int newHeight = 0;//<--|
		int newX = Integer.MAX_VALUE;
		int newY = Integer.MAX_VALUE;
		int uDim = 0;
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				// x
				uDim = unit.getX();
				if (newX > uDim) {
					newX = uDim;
				}
				// y
				uDim = unit.getY();
				if (newY > uDim) {
					newY = uDim;
				}
			}
		}
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				// width
				uDim = unit.getX() + unit.getWidth() - newX;
				if (newWidth < uDim) {
					newWidth = uDim;
				}
				// height
				uDim = unit.getY() + unit.getHeight() - newY;
				if (newHeight < uDim) {
					newHeight = uDim;
				}
			}
		}
		//System.out.println("setting bounds of AGroup to: \nX = "+(newX-GAP_SIZE/2)+" Y = "+(newY-GAP_SIZE/2)+" width = "+(newWidth+GAP_SIZE)+" height = "+(newHeight+GAP_SIZE));
		setBounds(newX - GAP_SIZE / 2, newY - GAP_SIZE / 2, newWidth + GAP_SIZE, newHeight + GAP_SIZE);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (drawBox) {
			g.setColor(Color.black);
			g.drawRect(1, 1, getWidth() - 1, getHeight() - 1);
		}
	}

	public AUnit[] getUnits() {
		return units.toArray(new AUnit[units.size()]);
	}

	public Iterator<AUnit> getUnitsIterator() {
		return units.iterator();
	}

	@Override
	public void moveTo(int x, int y) {
		int aggx = getX();
		int aggy = getY();
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.moveTo(x + unit.getX() - aggx, y + unit.getY() - aggy);
			}
		}
	}

	/**
	 * adjust x coord by <code>x</code> and y coord by <code>y</code>. (they can be negative)
	 */
	@Override
	public void moveBy(int x, int y) {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.moveBy(x, y);
			}
		}
	}

	public void doNotPaintCrossOfUnits() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.doNotPaintCross();
			}
		}
	}

	public void doPaintCrossOfUnits() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.doPaintCross();
			}
		}
	}

	/**
	 * sets the <code>showStatus</code> flag of the <code>AUnits</code> in <code>units</code> to false and hides the status box
	 */
	public void doNotShowStatusofUnits() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.doNotShowStatus();
				unit.hideStatusBox();
			}
		}
	}

	/**
	 * sets the <code>showStatus</code> flag of the <code>AUnits</code> in <code>units</code> to true
	 */
	public void doShowStatusOfUnits() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.doShowStatus();
			}
		}
	}

	/**
	 * creates(if needed) and displays the status box of the <code>AUnits</code> in <code>units</code> if <code>showstatus</code> flag is set
	 * NOTE: this method is not to be confused with <code>doShowStatus()</code> which just sets the <code>showStatus</code> flag to true
	 */
	@Override
	public void showStatusBox() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.showStatusBox();
			}
		}
	}

	/**
	 * hide the status box if this is not selected
	 * NOTE: this method is not to be confused with <code>doNotShowStatus()</code> which just sets the <code>showStatus</code> flag to false
	 */
	@Override
	public void hideStatusBox() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.hideStatusBox();
			}
		}
	}

	/**
	 * correct the position of the Status display box of the <code>AUnits</code> in <code>units</code>
	 */
	public void correctStatDispBoxPosOfUnits() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.correctStatDispBoxPos();
			}
		}
	}

	public boolean isOneOrMoreUnitsSelected() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null && unit.isSelected()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void select() {
		deselectUnits();
		selectUnitsPseudo();
		super.select();
		//System.out.println("AG_SELECTED");
	}

	@Override
	public void deselect() {
		deselectUnitsPseudo();
		super.deselect();
	}

	@Override
	public void deselectPseudo() {
		deselectUnitsPseudo();
		super.deselectPseudo();
	}

	public void selectUnits() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.select();
			}
		}
	}

	public void selectUnitsPseudo() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.pseudoSelect();
			}
		}
	}

	public void deselectUnits() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.deselect();
			}
		}
	}

	public void deselectUnitsPseudo() {
		AUnit unit;
		for (Iterator<AUnit> it = units.iterator(); it.hasNext();) {
			unit = it.next();
			if (unit != null) {
				unit.deselectPseudo();
			}
		}
	}

	//====================Mouse Listeners========================
	@Override
	public void mousePressed(MouseEvent e) {
		if ((e.getButton() == 2 || e.getButton() == 3) && isOneOrMoreUnitsSelected()) {
			getAMP().notifyOfMousePress(this, e);
		} else {
			super.mousePressed(e);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		//System.out.println("OVER");
		super.mouseEntered(e);
		drawBox = true;
	}

	@Override
	public void mouseExited(MouseEvent e) {
		//System.out.println("OFF");
		super.mouseExited(e);
		drawBox = false;
	}
}
