/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.gameObjects;

import assault.game.APlayer;
import assault.game.display.ACommandButton;
import assault.game.util.pathfinding.PathFindingGridObject;
import assault.game.util.pathfinding.PathObject;
import assault.game.loading.resourceHolders.ResourceHolderException;
import assault.game.loading.resourceHolders.UnitResourceHolder;
import assault.game.loading.resourceHolders.WeaponResourceHolder;
import java.awt.Graphics;
import java.awt.Point;

/**
 *
 * @author matt
 */
public class AUnit extends AObject implements PathFindingGridObject {

	private AGroup aGroup = null;
	private ACommandButton[] cmdBtnSet = new ACommandButton[0];
	private Point createPoint = new Point(0, 0);
	private Point[] mountPoints;
	private AWeapon[] weapons;
	/**
	 * this array will replaced dynamically, therefore 
	 * it should never be referenced directly, and 
	 * always copied (through copyNextMoves())when used. 
	 * The byte nextMovesHasChanged should be checked for
	 * a different value (or 0) than it was when the array was
	 * first copied to see if it has been updated. this is done
	 * in copyNextMoves()
	 */
	private Point[] nextMoves = new Point[0];
	/**
	 * the lock associated with nextMoves
	 */
	private final Object NM_LOCK = new Object();
	/**
	 * 0 when no moves, and increments (until max value has been
	 * reached, then back to one) each time the nextMoves 
	 * array has changed (when this happens, get a new copy via
	 * copyNextMoves())
	 */
	private byte nextMovesHasChanged = 0;

	public AUnit(int x, int y, UnitResourceHolder src, APlayer owner) throws ResourceHolderException {
		super(x, y, src, owner);
		setCreatePoint(src.getCreatePoint());
		setCmdBtnSet(src.getCmdBtns());
		setMountPoints(src.getMountPoints());
		WeaponResourceHolder[] weaponsSources = src.getWeapons();
		for (int i = 0; i < weaponsSources.length; i++) {
			if (getMountPoint(i) != null && weaponsSources[i] != null) {
				equipWeapon(new AWeapon(weaponsSources[i], owner), i);
			}
		}
	}

	public AUnit(APlayer owner) {
		super(owner);
	}

	@Override
	public void addSubPartsToAMP() {
		super.addSubPartsToAMP();
		if (getAMP() != null) {
			if (weapons != null) {
				for (int i = 0; i < weapons.length; i++) {
					getAMP().add(weapons[i], false);
				}
			}
		}
	}
	
	@Override
	public void updateSubPartsPosition() {
		super.updateSubPartsPosition();
		if (weapons != null) {
				for (int i = 0; i < weapons.length; i++) {
					if (weapons[i]!=null){
						weapons[i].refreshPosition();
					}
				}
			}
	}
	
	

	protected final boolean equipWeapon(AWeapon aw, int mountNum) {
		//System.out.println("AUNIT_EQUIP_WEAPON");
		if (mountNum < weapons.length && mountNum >= 0 && hasWeapon(aw) < 0 && aw != null) {
			if (aw.mountOn(this, mountNum)) {
				weapons[mountNum] = aw;
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	private void removeWeapon(int mountNum) {
		if (mountNum < weapons.length && mountNum >= 0) {
			weapons[mountNum].dispose();
			weapons[mountNum] = null;
		}
	}

	public final AWeapon getWeapon(int mountNum) {
		if (mountNum < weapons.length && mountNum >= 0) {
			return weapons[mountNum];
		}
		return null;
	}

	/**
	 * the mount number of that weapon or -1 if this
	 * AUint doesn't have it or aw is null. 
	 * @param aw
	 * @return 
	 */
	public final int hasWeapon(AWeapon aw) {
		if (aw != null) {
			for (int i = 0; i < weapons.length; i++) {
				if (weapons[i] == aw) {
					return i;
				}
			}
		}
		return -1;
	}

	final Point getMountPoint(int number) {
		if (number >= 0 && number < mountPoints.length && mountPoints[number] != null) {
			return new Point(mountPoints[number]);
		} else {
			return null;
		}
	}

	/**
	 * adjust x co-ord by <code>x</code> and y co-ord by <code>y</code>. (they can be negative)
	 */
	public void moveBy(int x, int y) {
		moveTo(getX() + x, getY() + y);
	}

	/**
	 * try to get as close as possible to (x,y)
	 * @param x
	 * @param y
	 */
	public void moveTo(final int x, final int y) {
		new Thread(new Runnable() {

			@Override
			public void run() {
				PathObject po = getAMP().getPF().findPath(AUnit.this, x, y);
				synchronized (NM_LOCK) {
					if (po != null) {
						nextMoves = po.points;
						if (nextMovesHasChanged == Byte.MAX_VALUE) {
							nextMovesHasChanged = 1;
						} else {
							nextMovesHasChanged++;
						}
					} else {
						nextMovesHasChanged = 0;//causes copyNextMoves() to return null
						nextMoves = null;
					}
				}
			}
		}).start();

	}

	public void moveTo(Point p) {
		//if (p != null){
		moveTo(p.x, p.y);
		//}
	}

	/**
	 * Copies and returns the nextMoves Point array for use with moving.
	 * The oldNMHC parameter is compared to nextMovesHasChanged, if it differs
	 * this returns the new Point[]. If it is the same, this returns the
	 * currentPoints parameter. If nextMovesHasChanged == 0, then this returns null.
	 * <p>
	 * Note that the nextMoves array should only be used directly in a
	 * synchronized context on the lock NM_LOCK.
	 * 
	 * @param oldNMHC the old
	 * @param currentPoints the current Point[] that 
	 * @return a copy of nextMoves if olNMC is different, or null if nextMovesHasChanged == 0
	 */
	private Point[] copyNextMoves(byte oldNMHC, Point[] currentPoints) {
		synchronized (NM_LOCK) {
			if (nextMovesHasChanged == 0) {
				return null;
			} else {
				if (nextMovesHasChanged == oldNMHC) {
					return currentPoints;
				} else {
					Point[] pts = new Point[nextMoves.length];
					System.arraycopy(nextMoves, 0, pts, 0, nextMoves.length);
					return pts;
				}
			}
		}
	}
	private byte oldNMHC = 0;
	private Point[] nextMovesCopy = null;
	private int nextMoveIndex = 0;

	public void advance() {
		//System.out.println("AU_ADVANCE");
		synchronized (NM_LOCK) {
			//System.out.println("AU_ADVANCE_GOT_LOCK");
			nextMovesCopy = copyNextMoves(oldNMHC, nextMovesCopy);
			if (oldNMHC != nextMovesHasChanged) {
				//move the pointer to the beginning of the array
				nextMoveIndex = 0;
				oldNMHC = nextMovesHasChanged;
			}
		}
		//System.out.println("AU_ADVANCE_RELINQUISHED_LOCK");
		if (nextMovesCopy != null) {
			if (nextMoveIndex < nextMovesCopy.length) {
				if (getAMP().getGM().notifyOfImminentMovement(this, getLocation(), nextMovesCopy[nextMoveIndex])) {
					//System.out.println("AU_ADVANCING");
					setLocation(nextMovesCopy[nextMoveIndex]);
					setCreatePoint(nextMovesCopy[nextMoveIndex]);
					resizeAGroup();
					correctStatDispBoxPos();
					nextMoveIndex++;
					//System.out.println("AU_MOVED");
				}// else {
				//System.out.println("AU_NOT_MOVED");
				//TODO put some logic here to recalculate path
				//}
			} else {
				//when there are no moves left
				nextMoveIndex = 0;
				nextMovesCopy = null;
				//System.out.println("AU_ADVANCE_NOT_MOVED(NONE_LEFT)");
			}
		}// else {
		//the list is null(@see copyNextMoves())
		//System.out.println("AU_ADVANCE_NOT_MOVED(NULL)");
		//}
	}

	private void resizeAGroup() {
		if (aGroup != null) {
			aGroup.resizeToUnits();
		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
		//System.out.println("AU_PAINT");
	}

	public void shootBulletAt(AObject target, AWeapon aw) {
		if (hasWeapon(aw) >= 0) {
			aw.shoot(target);
		}
	}

	public void shootBulletAt(AObject target, int mountNum) {
		if (mountNum < weapons.length && mountNum >= 0 && weapons[mountNum] != null) {
			weapons[mountNum].shoot(target);
		}
	}

	/**
	 * add this to <code>ag</code>, while overwriting and removing
	 * it from the previous <code>AGroup</code> (if there was one)
	 * @param ag <code>AGroup</code> to be added to
	 */
	public void registerGroup(AGroup ag) {
		if (aGroup != ag) {
			removeFromGroup();
			aGroup = ag;
		}
	}

	public void changeGroup(AGroup ag) {
		registerGroup(ag);
		ag.addUnit(this);
	}

	public void removeFromGroup() {
		if (aGroup != null) {
			aGroup.removeUnit(this);
			aGroup = null;
		}
	}

	public final void setCmdBtnSet(ACommandButton[] acbs) {
		if (acbs != null) {
			cmdBtnSet = acbs;
		} else {
			cmdBtnSet = new ACommandButton[0];
		}
	}

	public ACommandButton[] getCmdBtnSet() {
		return cmdBtnSet;
	}

	private void setMountPoints(Point[] pts) {
		mountPoints = new Point[pts.length];
		for (int i = 0; i < pts.length; i++) {
			if (pts[i] == null) {
				continue;//keep it null
			} else {
				mountPoints[i] = new Point(pts[i]);
			}
		}
		if (weapons != null) {
			AWeapon[] tempW = new AWeapon[pts.length];
			System.arraycopy(weapons, 0, tempW, 0, tempW.length);
			weapons = tempW;
		} else {
			weapons = new AWeapon[pts.length];
		}
	}

	/**
	 * will remove this from parent and take care of any duties to remove it completely.
	 */
	@Override
	protected synchronized void dispose() {
		if (!isDisposed()) {
			removeFromGroup();
			getAMP().remove(weapons);
			System.out.println("AU_DISPOSE");
		}
		super.dispose();
	}

	/**
	 * get the point to create new AObjects
	 * This one is NOT relative!
	 * @return 
	 */
	public Point getCreatePoint() {
		return new Point(createPoint);
	}

	/**
	 * set the point <i>relative</i> to the origin of this AObject,
	 * where new AObjects will be created. 
	 * This method calculates the actual create point
	 * from the relative one given.
	 * @param x a relative x
	 * @param y a relative y
	 */
	private void setCreatePoint(int x, int y) {
		createPoint.x = x + getX();
		createPoint.y = y + getY();
	}

	/**
	 * set the point <i>relative</i> to the origin of this AObject,
	 * where new AObjects will be created.
	 * @see setCreatePoint(int,int)
	 * @param p a point relative to this AU's origin
	 */
	private void setCreatePoint(Point p) {
		setCreatePoint(p.x, p.y);
	}

	@Override
	public UnitResourceHolder getSrc() {
		return (UnitResourceHolder) super.getSrc();
	}
	//for pathfinding
	boolean[][] examined;
	boolean[][] open;
	boolean[][] onPath;
	boolean[][] closed;

	@Override
	public boolean[][] getExamined() {
		return examined;
	}

	@Override
	public boolean[][] getOnOpenSet() {
		return open;
	}

	@Override
	public boolean[][] getOnPath() {
		return onPath;
	}

	@Override
	public boolean[][] getClosedSet() {
		return closed;
	}

	@Override
	public void setExamined(boolean[][] exa) {
		examined = exa;
	}

	@Override
	public void setOnOpenSet(boolean[][] open) {
		this.open = open;
	}

	@Override
	public void setOnPath(boolean[][] onPath) {
		this.onPath = onPath;
	}

	@Override
	public void setClosedSet(boolean[][] closed) {
		this.closed = closed;
	}
}
