/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.loading.resourceHolders;

/**
 *
 * @author matt
 */
public class ResourceHolderException extends Exception {

	private String reasonString;
	public ResourceHolderException(String location, Exception reason) {
		this(location, reason == null ? null : reason.toString());
		
	}
	public ResourceHolderException(String location, String reason){
		if (reason != null && location != null){
			reasonString = location +": "+ reason;
		}else if (location != null){
			reasonString = location;
		}else if (reason != null){
			reasonString = reason;
		}else{
			reasonString = "";
		}
	}
	public ResourceHolderException(String reason){
		reasonString = reason;
	}
	public String getReason(){
		return reasonString;
	}

	@Override
	public String toString() {
		return reasonString;
	}
	
	
}
