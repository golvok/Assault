/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.display;

import assault.game.util.commands.ACommand;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.SwingConstants;

/**
 *
 * @author matt
 */
public class ACommandButton extends AButton {

	private ACommand cmd;
	private ACommandButton btnRef = this;

	public ACommandButton(ACommand acmd) {
		super(acmd.getName(), acmd.getShortCut(), acmd.getIcon());
		cmd = acmd;
		setVerticalTextPosition(SwingConstants.BOTTOM);
		setHorizontalTextPosition(SwingConstants.CENTER);
		setEnabled(acmd.isValidCommand());
		setAction(new AbstractAction() {

			private ACommandDispatchMenu acdm;

			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println(acmd.getName()+ " button was pressed.");
				new Thread(new Runnable() {

					@Override
					public void run() {
						//TODO is there a better way to do commands from buttons?
						if (cmd.isValidCommand()) {
							try {
								//btnRef.setEnabled(false);
								acdm = getAW().getACDM();
								acdm.disableAllExceptEsc();
								getAMP().executeCommandOnSelectionBySelection(cmd);
								//System.out.println("Next mousePress was acknowledged");
							} catch (Exception ex) {
								ex.printStackTrace();
							}
							acdm.enableAll();
						}
					}
				}).start();
			}
		});
	}

	@Override
	public void setEnabled(boolean bln) {
		if (cmd.isValidCommand() || !bln) {
			super.setEnabled(bln);
		}
	}

	public ACommand getCmd() {
		return cmd;
	}
}
