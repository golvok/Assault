/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.loading.resourceHolders;

import assault.game.loading.ResourcePreloader;
import java.io.File;

/**
 *
 * @author matt
 */
public abstract class ResourceHolder {

	protected ResourcePreloader rp;
	protected File baseFile;
	private boolean isvalid = false;

	public ResourceHolder(ResourcePreloader rp, String location) throws ResourceHolderException {
		this(rp, new File("lib/ASSAULT_DATA", location));
		System.out.println("  " + "relative location = " + location);
	}

	public ResourceHolder(ResourcePreloader rp, File location) throws ResourceHolderException {
		if (!checkAccess(location)) {
			throw new ResourceHolderException("could not access location for resource (or it's null) @ " + location.getAbsolutePath());
		}
		/*if (location == null){
		throw new ResourceHolderException("location was null");
		}else if (location.exists()){
		throw new ResourceHolderException(location+" doesn't exist");
		}else if (location.canRead()){
		throw new ResourceHolderException("do not have permission to read "+location);
		}*/
		if (rp == null) {
			//assumes that location is not null because it has allready been checked
			throw new ResourceHolderException("ResourcePreloader was null when creating ResourceHolder for\n\t|->" + location);
		}
		this.rp = rp;
		System.out.println("           " + "location = " + location.getPath());
		this.baseFile = location;
	}
	boolean loaded = false;//there are TO be used for load()
	boolean loading = false;

	public abstract void load() throws ResourceHolderException;
	// 
	// 
	boolean loadedReferencial = false;//there are TO be used for loadReferencial()
	boolean loadingReferencial = false;

	public abstract void loadReferencial() throws ResourceHolderException;

	public static boolean checkAccess(File f) {
		return f != null
				&& f.exists()
				&& f.canRead();
	}

	protected void setValid(boolean b) {
		isvalid = b;
	}

	public boolean isValid() {
		return isvalid;
	}
}
