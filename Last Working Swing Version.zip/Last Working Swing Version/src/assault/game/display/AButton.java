/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game.display;

import assault.AssaultWindow;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import org.lwjgl.opengl.GL11;

/**
 *
 * @author matt
 */
public class AButton extends JButton{

	public static final int BUTTON_WIDTH = 30;
	public static final int BUTTON_HEIGHT = 30;
	private int index = -1;
	private String name;
	private char shortCut;
	private ImageIcon icon;
    private AssaultWindow AssaultWindow;

	public AButton(String name, char shortCut, ImageIcon icon) {
        //super(0, 0, BUTTON_HEIGHT, BUTTON_WIDTH);
		this.name = name;
		if (shortCut != '\u0000'){
			this.shortCut = shortCut;
			setMnemonic(shortCut);
		} else {
			this.shortCut = '-';
			setMnemonic('-');
		}
		//setToolTipText(name+" ("+shortCut+")");
		//the icon is set in setIndex().
		setIcon(icon);
	}
    //@Override
	protected void draw(GL11 gl) {
		//g.drawImage(acmd.getIcon().getImage(), 0, 0, null);
		//g.drawString(acmd.getName(), 0, getHeight()-12);
	}
	/**
	 * sets the index, the bounds of
	 * this as if it were in the ACDM
	 * 
	 * @param index
	 */
	void setIndex(int index, int numColumns){
		if (this.index != index){
			this.index = index;
			setBounds((index % numColumns)*AButton.BUTTON_WIDTH, ((int)Math.round(Math.floor(index/numColumns)))*AButton.BUTTON_WIDTH, AButton.BUTTON_WIDTH, AButton.BUTTON_HEIGHT);
		}
	}
	public GameArea getAMP() {
	    return getAW().getAMP();
	}
    
	public AssaultWindow getAW() {
	    return AssaultWindow;
	}

    //private void setMnemonic(char shortCut) {
        
    //}

    private void setIcon(ImageIcon i) {
        icon = i;
    }
}

