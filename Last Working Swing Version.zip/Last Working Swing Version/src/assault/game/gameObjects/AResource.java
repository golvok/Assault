/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game.gameObjects;

import assault.game.loading.resourceHolders.ObjectResourceHolder;
import assault.game.loading.resourceHolders.ResourceHolderException;
import assault.game.loading.resourceHolders.ResourceResourceHolder;

/**
 *
 * @author matt
 */
public class AResource extends AObject{

	public AResource(int x,int y, ResourceResourceHolder src) throws ResourceHolderException {
		super(x, y, (ObjectResourceHolder)src, null);
	}

}
