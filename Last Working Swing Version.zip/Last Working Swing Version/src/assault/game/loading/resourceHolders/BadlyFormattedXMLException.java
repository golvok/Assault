/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.loading.resourceHolders;

/**
 *
 * @author matt
 */
public class BadlyFormattedXMLException extends ResourceHolderException {

	public BadlyFormattedXMLException(String location, Exception reason) {
		super(location,reason);
	}
	public BadlyFormattedXMLException(String location, String reason){
		super(location, reason);
	}
	public BadlyFormattedXMLException(String reason){
		super(reason);
	}
	
}
