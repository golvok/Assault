/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault;

import assault.game.display.ACommandDispatchMenu;
import assault.game.display.AStatusDisplayMenu;
import assault.game.APlayer;
import assault.game.APlayer;
import assault.game.display.GameArea;
import assault.game.gameObjects.AGroup;
import assault.game.gameObjects.AUnit;
import assault.game.loading.ResourcePreloader;
import assault.game.loading.resourceHolders.ResourceHolderException;
import assault.game.loading.resourceHolders.UnitResourceHolder;
import java.awt.Color;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

import static org.lwjgl.opengl.GL11.*;

/**
 *
 * @author matt
 */
public class AssaultWindow {

    private long lastframe;
    private double lastFps = 0;
    private GameArea gameArea;
    private ResourcePreloader rp;
    private ACommandDispatchMenu commandDispatchMenu;
    private AStatusDisplayMenu statusDisplayMenu;

    private void init() {
        initGL();
        getDelta();//to initialize this method

        /** Creates new form AGameViewer */
        //this is used as a temp proxy to avoid annoying casts to GameArea
        gameArea = new GameArea();
        String[] mods = {
            "default",};

        final APlayer p1;
        final APlayer p2;
        final ResourcePreloader rp;
        p1 = new APlayer(Color.red);
        p2 = new APlayer(Color.orange);
        rp = new ResourcePreloader(mods, getAMP());
        new Thread(new Runnable() {

            @Override
            public void run() {
                synchronized (this) {
                    try {
                        wait(3000);
                    } catch (InterruptedException ex) {
                    }
                }
                rp.start();
                try {
                    AUnit en2 = new AUnit(105, 300, rp.getModUnitByName("default", "SimpleUnit2"), p1);
                    gameArea.add(en2);

                    AUnit b1 = new AUnit(505, 100, rp.getModUnitByName("default", "SimpleBuilding"), p1);
                    gameArea.add(b1);

                    AUnit e1 = new AUnit(105, 400, rp.getModUnitByName("default", "SimpleUnit2"), p2);
                    gameArea.add(e1);

                    AUnit e2 = new AUnit(505, 200, rp.getModUnitByName("default", "SimpleBuilding"), p2);
                    gameArea.add(e2);

                    AUnit e3 = new AUnit(605, 50, rp.getModUnitByName("default", "SimpleUnit"), p2);
                    gameArea.add(e3);

                    AUnit u1 = new AUnit(605, 100, rp.getModUnitByName("default", "SimpleUnit"), p1);
                    gameArea.add(u1);
                    AUnit u2 = new AUnit(705, 100, rp.getModUnitByName("default", "SimpleUnit2"), p1);
                    gameArea.add(u2);
                    AUnit u3 = new AUnit(805, 100, rp.getModUnitByName("default", "SimpleUnit"), p1);
                    gameArea.add(u3);
                    AUnit[] gu1 = {u1, u2, u3};
                    AGroup g1 = new AGroup(gu1, p1);
                    gameArea.add(g1);

                    UnitResourceHolder su1 = rp.getModUnitByName("default", "SimpleUnit");
                    for (int i = 0; i <= 6; i++) {
                        gameArea.add(new AUnit((i * 58) + 100, 200, su1, p1));
                    }

                    UnitResourceHolder su2 = rp.getModUnitByName("default", "SimpleUnit2");
                    for (int i = 0; i <= 6; i++) {
                        gameArea.add(new AUnit((i * 65) + 100, 500, su2, p2));
                    }

                } catch (ResourceHolderException ex) {
                    rp.addError(ex);
                }
                synchronized (this) {
                    try {
                        wait(2000);
                    } catch (InterruptedException ex) {
                    }
                    gameArea.remove(rp);
                }
            }
        }).start();
    }

    private void initGL() {

        //init
        glShadeModel(GL_SMOOTH);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 800, 600, 0, 300, -300);
        glMatrixMode(GL_MODELVIEW);
    }

    public void start() {
        try {
            Display.setDisplayMode(new DisplayMode(800, 600));
            Display.create();
        } catch (LWJGLException e) {
            e.printStackTrace();
            System.exit(0);
        }


        init();


        //System.out.println(glGetInteger(GL_MAX_PROJECTION_STACK_DEPTH));

        while (!Display.isCloseRequested()) {

            update(getDelta());
            renderGraphics();
            /*synchronized (this) {
            try {
            wait(50);
            } catch (InterruptedException ex) {
            
            }
            }*/
            Display.update();
            Display.sync(60);
        }

        Display.destroy();
    }

    private void update(int delta) {
        Display.setTitle("AssaultWindow @ " + ((int) (lastFps * 100d)) / 100d + " fps");
        updateFps(delta);
    }

    private void renderGraphics() {
        glClearColor(.5f, .5f, 1f, 1f);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


        glPopMatrix();
    }

    /**
     * 
     * @return the difference in milliseconds since the last time this method was called
     */
    private int getDelta() {
        long time = getTime();
        int delta = (int) (time - lastframe);
        lastframe = time;
        return delta;
    }

    private long getTime() {
        return Sys.getTime() * 1000 / Sys.getTimerResolution();
    }

    public static void main(String[] argv) {
        AssaultWindow newThis = new AssaultWindow();
        newThis.start();
    }

    private void updateFps(int delta) {
        if (delta != 0) {
            lastFps = 1000d / ((double) delta);
        } else {
            lastFps = -1;
        }
    }
    public AStatusDisplayMenu getASDM() {
		return statusDisplayMenu;
	}

	public ACommandDispatchMenu getACDM() {
		return commandDispatchMenu;
	}

	public GameArea getAMP() {
		return gameArea;
	}

	public ResourcePreloader getRP() {
		return rp;
	}
}
