/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.gameObjects;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import javax.swing.JComponent;
import org.lwjgl.opengl.GL11;

/**
 *
 * @author matt
 */
public abstract class APaintable extends JComponent {

	private int x;
	private int y;
	private int width;
	private int height;
    private boolean visible;

	public APaintable(int x, int y, int width, int height) {
		super();
		setLocation(x, y);
		setSize(width, height);
	}
    
    //protected abstract void draw(GL11 GL);
    
	public int getWidth() {
		return width;
	}
    
	public int getHeight() {
		return height;
	}
    
	public Point getLocation() {
		return new Point(x, y);
	}

	public Point getLocation(Point rv) {
		if (rv == null) {
			return new Point(x, y);
		} else {
			rv.setLocation(x, y);
			return rv;
		}
	}

	public Rectangle getBounds() {
		return new Rectangle(x, y, width, height);
	}

	public Rectangle getBounds(Rectangle rv) {
		if (rv == null) {
			return new Rectangle(x, y, width, height);
		} else {
			rv.setBounds(x, y, width, height);
			return rv;
		}
	}

	public Dimension getSize() {
		return new Dimension(width, height);
	}

	public Dimension getSize(Dimension rv) {
		if (rv == null) {
			return new Dimension(width, height);
		} else {
			rv.setSize(width, height);
			return rv;
		}
	}
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void setSize(Dimension d) {
		setSize(d.width,d.height);
	}

	public void setSize(int width, int height) {
		this.width = width;
		this.height = height;
	}

	public void setBounds(Rectangle r) {
		setBounds(r.x,r.y,r.width,r.height);
	}

	public void setBounds(int x, int y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public void setLocation(Point p) {
		setLocation(p.x, p.y);
	}

	public void setLocation(int x, int y) {
		this.x = x;
		this.y = y;
	}
    
    public void setVisible(boolean b){
        visible = b;
    }
}
