/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game.display;

import assault.game.gameObjects.AObject;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author matt
 */
public class AStatusDisplayBox extends JPanel{
	/**
	 * this should never be used except to set boxHeight. Use boxHeight instead.
	 */
    protected final static int BOX_HEIGHT = 10;
	/**
	 * this should never be used except to set boxWidth. Use boxWidth instead.
	 */
    protected final static int BOX_WIDTH = 50;
	/**
	 * this should be used for all purposes instead of <code>BOX_HEIGHT</code> except to set this.
	 */
	protected int boxHeight;
	/**
	 * this should be used for all purposes instead of <code>BOX_WIDTH</code> except to set this.
	 */
	protected int boxWidth;//<-|
    protected AObject object;

    public AStatusDisplayBox(AObject obj){
		super(null);
		setOpaque(false);
		this.object = obj;
		setDimVars();
		fixBounds();
    }
	protected void setDimVars(){
		boxHeight = AStatusDisplayBox.BOX_HEIGHT;
		boxWidth = AStatusDisplayBox.BOX_WIDTH;
	}
    public void dispose(){
		object = null;
		getParent().remove(this);
    }
	public void correctPosition(){
		setLocation(object.getX(), object.getY());
		repaint();
	}
	public void fixBounds(){
		correctPosition();
		setSize(boxWidth+1, boxHeight+1);
	}

    public AObject getObject() {
        return object;
    }
    
    @Override
    protected void paintComponent(Graphics g){
		super.paintComponent(g);
		if (object != null){
			g.setColor(Color.black);
			g.drawRect(0, 0, boxWidth, boxHeight/3);
			g.setColor(Color.red);
			//accessing box* will get the value set by the SubClass in it's constructor(s) (unless it wasn't).
			g.fillRect(1, 1, (int)(Math.round((double)boxWidth*((double)object.getHealth()/(double)object.getMaxHealth())-(double)1)), (int)(Math.round((double)boxHeight/(double)3-(double)1)));
		}
		//System.out.println("ASDB_PAINT");
    }
}
