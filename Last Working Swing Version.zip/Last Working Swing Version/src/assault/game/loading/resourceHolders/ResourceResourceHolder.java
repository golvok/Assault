/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package assault.game.loading.resourceHolders;

import assault.game.loading.ResourcePreloader;
import assault.game.APlayer;
import assault.game.gameObjects.AObject;
import assault.game.gameObjects.AResource;
import java.awt.Point;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author matt
 */
public class ResourceResourceHolder extends ObjectResourceHolder{

	final static String RESOURCE_TYPE_NAME = "Resource";
	public ResourceResourceHolder(ModResourceHolder mod, File location, ResourcePreloader rp, SAXBuilder builder) throws BadlyFormattedXMLException, ResourceHolderException {
		super(mod, location, rp, builder);
	}

	@Override
	public AResource createObject(int x, int y, APlayer owner) {
		try {
			return new AResource(x, y, this);
		} catch (ResourceHolderException ex) {
			rp.addError(ex);
			return null;
		}
	}

	@Override
	public AObject createObject(Point p, APlayer owner) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

}
