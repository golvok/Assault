/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assault.game.display;

import assault.game.util.GridManager;
import assault.AGameViewer;
import assault.game.gameObjects.AGroup;
import assault.game.gameObjects.AObject;
import assault.game.gameObjects.APaintable;
import assault.game.gameObjects.AProjectile;
import assault.game.gameObjects.AUnit;
import assault.game.util.GridObject;
import assault.game.util.commands.ACommand;
import assault.game.util.commands.CreateCmd;
import assault.game.util.commands.MouseCommand;
import assault.game.util.commands.MoveCmd;
import assault.game.util.commands.NormalCommand;
import assault.game.util.commands.TargetCommand;
import assault.game.util.pathfinding.AStarPathFinder;
import assault.game.util.pathfinding.PathFinder;
import assault.game.util.pathfinding.PathFindingGridObject;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JLayeredPane;

/**
 *
 * @author matt
 */
public class GameArea extends JLayeredPane implements MouseListener, KeyListener, MouseMotionListener {

    public final static Integer GROUP_DEPTH = new Integer(1);
    public final static Integer NORMAL_DEPTH = new Integer(2);
    public final static Integer BULLET_DEPTH = new Integer(3);
    public final static Integer STATUS_BOX_DEPTH = new Integer(4);
    private List<AUnit> aUnits = Collections.synchronizedList(new ArrayList<AUnit>(32));
    private AObject[] selected = new AObject[1];
    private int numSelected = 0;
    private MoveCmd ampMover;
    private GridManager gManager;
    private Thread movementThread;
    private PathFinder pF;

    public GameArea() {
        super();
        setLayout(null);
        setFocusable(true);
        addMouseListener(this);
        addMouseMotionListener(this);
        //find a better way to do commands from the keyboard
        addKeyListener(this);
    }

    @Override
    public Component add(Component comp) {
        //System.out.println("added component normally to amp");
        return super.add(comp);
    }

    public void add(AStatusDisplayBox asdb) {
        super.add(asdb, STATUS_BOX_DEPTH);
    }

    /**
     * add(ap,true)
     * @param ap
     * @return 
     * @see add(APaintable ap, boolean addToGM)
     */
    public boolean add(APaintable ap) {
        return add(ap, true);
    }

    /**
     * add an APaintable to this AMP.
     * adds if (<code>addToGM</code>) AObjects, AGroups and AProjectiles are correctly added to the GridManager.
     * returns false if the GM refuses to add it.
     * @param ap
     * @param addToGM add to the gridmanager
     * @return true if successful, false if not
     */
    public boolean add(APaintable ap, boolean addToGM) {
        //this is here because getwidth + height are 0 until the constructor has been run for some reason (that's the general online response and my observations)
        if (gManager == null) {
            gManager = new GridManager(getWidth(), getHeight(), 10);
            //pF = new DijkstraPathFinder(getGM());
            pF = new AStarPathFinder(getGM());
        }
        if (movementThread == null) {
            movementThread = new Thread(new Runnable() {

                AUnit[] aUnitArray = new AUnit[0];

                @Override
                public void run() {
                    while (true) {
                        //System.out.println("MT_TICK");
                        synchronized (aUnits) {
                            //System.out.println("MT_GOT_LOCK");
                            aUnitArray = aUnits.toArray(aUnitArray);
                        }
                        //System.out.println("MT_RELINQUISH_LOCK");
                        for (int i = 0; i < aUnitArray.length; i++) {
                            if (aUnitArray[i] != null) {
                                aUnitArray[i].advance();
                            }
                        }
                        repaint();
                        synchronized (this) {
                            try {
                                //System.out.println("MT_WAITING");
                                wait(100);
                            } catch (InterruptedException ex) {
                            }
                        }
                    }
                    //movementThread = null;
                }
            });
            System.out.println("starting movement thread");
            movementThread.start();
        }

        if (ap != null) {
            if (addToGM && ap instanceof AObject && !(ap instanceof AGroup)) {
                if (!gManager.add((AObject) ap)) {
                    System.out.println("unable to add " + ap + " to AMP");
                    return false;
                }
            }
            if (ap instanceof AProjectile) {
                addProjectile((AProjectile) ap);
            } else if (ap instanceof AGroup) {//this extends AUnit, therefore
                addGroup((AGroup) ap);
            } else if (ap instanceof AUnit) {//_this_ must be below AGroup
                aUnits.add((AUnit) ap);
                super.add(ap, NORMAL_DEPTH);
            } else if (ap != null) {
                super.add(ap, NORMAL_DEPTH);
            }
            if (ap instanceof AObject) {
                ((AObject) ap).addSubPartsToAMP();
            }
            return true;
        } else {
            return false;
        }
    }

    private void addProjectile(AProjectile bu) {
        if (bu != null) {
            this.add(bu, BULLET_DEPTH);
        }
    }

    private void addGroup(AGroup ag) {
        if (ag != null) {
            this.add(ag, GROUP_DEPTH);
        }
    }

    public void addPaintables(APaintable[] aps) {
        for (int i = 0; i < aps.length; i++) {
            this.add(aps[i]);
        }
    }

    public void remove(AObject ao) {
        if (ao != null && !(ao instanceof AGroup)) {
            ao.deselect();
            getGM().remove(ao);
            if (ao instanceof AUnit) {
                aUnits.remove(ao);
            }
            super.remove(ao);
            repaint(ao.getBounds());
            System.out.println("AMP: removing " + ao);
        }
        System.out.println("AMP_REMOVE");
    }

    public void remove(AObject[] aos) {
        for (int i = 0; i < aos.length; i++) {
            remove(aos[i]);
        }
    }

    public void addToSelection(AObject[] aos) {
        for (int i = 0; i < aos.length; i++) {
            addToSelection(aos[i]);
        }
        repaint();
    }

    /**
     *
     * @param ao
     * @return true if it was added successfully false if not.
     */
    public boolean addToSelection(AObject ao) {
        for (int i = 0; i < selected.length; i++) {
            if (ao == selected[i]) {
                return false;
            }
        }
        int i = 0;
        if (numSelected + 1 > selected.length) {
            AObject[] temp = new AObject[selected.length + 5];
            System.arraycopy(selected, 0, temp, 0, selected.length);
            selected = temp;
            i = numSelected;//starts the loop below on a for-sure 1st null;
            //System.out.print("extended selection array first then ");
        }
        for (; i < selected.length; i++) {
            if (selected[i] == null) {
                selected[i] = ao;
                break;
            }
        }
        //System.out.println("searched for null in selection array");
        numSelected++;
        //System.out.println("numSelected = "+numSelected+" @AMP.addToSelection(AObject)");
        getAGV().getASDM().addBox(ao);
        getAGV().getACDM().setCmdBtns(selected);
        repaint();
        return true;
    }

    public void removeFromSelection(AObject ao) {
        boolean removedSomething = false;
        for (int i = 0; i < selected.length; i++) {
            if (ao.equals(selected[i])) {
                cancelAllUIWaitingThreads();
                selected[i] = null;
                removedSomething = true;
                break;
            }
        }
        if (!removedSomething) {
            System.out.println(ao.getClass() + " wasn't in the selection when AMP.removeFromSelection(AObject) was attempted, did nothing");
        } else {
            numSelected--;
            getAGV().getACDM().setCmdBtns(getSelection());
            getAGV().getASDM().removeBox(ao);
            repaint();
        }
        //System.out.println("numSelected = "+numSelected+" @AMP.removeFromSelection(AObject)");
    }

    /**
     * deselectPseudo()s everything and does the same thing
     * as {@link #removeFromSelection(AObject)} except more efficiently.
     */
    public void deselectAll() {
        cancelAllUIWaitingThreads();
        for (int i = 0; i < selected.length; i++) {
            if (selected[i] != null) {
                selected[i].deselectPseudo();//a full deselect would call removeFromSelection(AObject) which would be less efficient
                //System.out.println(selected[i].getClass() +" was deselectPseudo()ed @AMP.deselectAll()");
                selected[i] = null;
                numSelected--;
            }
        }
        getAGV().getASDM().removeAllBoxes();
        getAGV().getACDM().removeAllCmdBtns();
        if (numSelected != 0) {
            System.err.println("numSelected = " + numSelected + " at end of @AMP.deselectAll() --- IT WAS NON ZERO!!!");
        }
        repaint();
        //System.out.println("numSelected = "+numSelected+" @AMP.deselectAll()");
    }

    /**
     * checks if numSelected is > 0 true if it is, false otherwise
     * @return if this <code>GameArea</code> has a selection, return true. false otherwise.
     */
    public boolean hasSelection() {
        return numSelected > 0;
    }

    /**
     * Starts at this instance's parent, checks if it is an instance of the AGameViewer class,
     * if it is, returns it, if it's not checks the parent's parent and so on. If any parent is null returns null
     * @return First instance of AGameViewer that is found when going up through this instance's lineage. If any parent is null returns null
     */
    public AGameViewer getAGV() {
        for (Container p = this; p != null; p = p.getParent()) {
            //System.out.println(p);
            if (p instanceof AGameViewer) {
                return (AGameViewer) p;
            }
        }
        return null;
    }

    public AObject[] getSelection() {
        return selected;
    }

    private AUnit[] getAUnitSelection() {
        AUnit[] aus = new AUnit[getSelection().length];
        int j = 0;
        for (int i = 0; i < selected.length; i++) {
            if (selected[i] instanceof AUnit) {
                aus[j] = (AUnit) selected[i];
                j++;
            }
        }
        return aus;
    }

    /**
     * Makes it so that ao is the only thing selected. Really
     * only should be used from within the AMP (keep it private
     * please) seeing as it does not call select() on ao.
     * @param ao
     */
    private void setSelection(AObject ao) {
        deselectAll();
        selected = new AObject[3];
        selected[0] = ao;
        numSelected++;
        //boxes and cmds are removed in deselectAll()
        getAGV().getASDM().addBox(ao);
        getAGV().getACDM().setCmdBtns(ao);
    }

    public GridManager getGM() {
        return gManager;
    }

    public PathFinder getPF() {
        return pF;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        //System.out.println("AMP_PAINT");
        Graphics sg = g.create();
        if (numSelected == 1 && selected[0] instanceof PathFindingGridObject && getPF() != null) {
            PathFindingGridObject pfgo = (PathFindingGridObject) selected[0];
            if (pfgo.getExamined() != null && pfgo.getOnOpenSet() != null && pfgo.getOnPath() != null) {
                boolean[][] exa = pfgo.getExamined();
                boolean[][] open = pfgo.getOnOpenSet();
                boolean[][] path = pfgo.getOnPath();
                boolean[][] closed = pfgo.getClosedSet();
                for (int i = 0; i < exa.length; i++) {
                    for (int j = 0; j < exa[i].length; j++) {
                        if (path[i][j]) {
                            sg.setColor(Color.CYAN);
                            sg.fillRect(getGM().convGridToPixel(i) + 1, getGM().convGridToPixel(j) + 1, getGM().getGridSize() - 1, getGM().getGridSize() - 1);
                        } else if (closed[i][j]) {
                            sg.setColor(Color.RED);
                            sg.fillRect(getGM().convGridToPixel(i) + 1, getGM().convGridToPixel(j) + 1, getGM().getGridSize() - 1, getGM().getGridSize() - 1);
                        } else if (open[i][j]) {
                            sg.setColor(Color.BLUE);
                            sg.fillRect(getGM().convGridToPixel(i) + 1, getGM().convGridToPixel(j) + 1, getGM().getGridSize() - 1, getGM().getGridSize() - 1);
                        } else if (exa[i][j]) {
                            sg.setColor(Color.BLACK);
                            sg.fillRect(getGM().convGridToPixel(i) + 1, getGM().convGridToPixel(j) + 1, getGM().getGridSize() - 1, getGM().getGridSize() - 1);
                        }
                    }
                }
            }
        }
    }

    public void executeCommandOnSelectionBySelection(ACommand cmd) {
        executeCommand(cmd, getSelection(), getAUnitSelection());
    }

    /**
     * executes the <code>ACommand</code> on the specified target(s),
     * getting mouse presses and targets required by the various
     * <code>ACommand</code> interfaces. NOTE: It will not return until the
     * command can be fully executed. Ie. until the next mouse press
     * is detected the the command is executed.
     * @param cmd
     * @param targets
     */
    public void executeCommand(ACommand cmd, AObject[] targets, AUnit[] executors) {
        if (cmd instanceof CreateCmd) {
            for (int i = 0; i < executors.length; i++) {
                AUnit builder = executors[i];
                //System.out.println("executing CreateCmd");
                ((CreateCmd) cmd).execute(builder, this);
            }
        } else if (cmd instanceof TargetCommand) {
            AObject target = getNextAObjectTargeted();
            ((TargetCommand) cmd).executeOn(targets, (AObject) target);
        } else if (cmd instanceof MouseCommand) {
            Point mouse = getnextMousePress();
            ((MouseCommand) cmd).executeOn(targets, mouse.x, mouse.y);
        } else if (cmd instanceof NormalCommand) {
            ((NormalCommand) cmd).execute();
        } else {
            System.out.println("Command didn't implement an interface or that interface isn't implemented in the AMP");
        }
    }
    private Point nextMousePress = null;
    private Thread NMPWaitingThread = null;
    private boolean NMPWTCanceled = false;

    /**
     * causes the thread to wait until a mouse press has occurred
     * and returns the location as a point or null if it is canceled.
     * @return the location of the next mouse press.
     */
    synchronized Point getnextMousePress() {
        //System.out.println("Waiting for next mouse press...");
        NMPWTCanceled = false;
        Point p;
        NMPWaitingThread = Thread.currentThread();
        synchronized (Thread.currentThread()) {
            while (nextMousePress == null) {
                try {
                    Thread.currentThread().wait();
                } catch (InterruptedException ex) {
                }
                if (NMPWTCanceled) {
                    nextMousePress = null;
                    break;
                }
            }
        }
        p = nextMousePress;
        nextMousePress = null;
        NMPWaitingThread = null;
        System.out.println("returning the next mouse press. canceled : " + NMPWTCanceled);
        return p;
    }

    private boolean isANextMousePressWaitingThread() {
        return NMPWaitingThread != null;
    }

    private void notifyOfNextMousePress(int x, int y) {
        if (isANextMousePressWaitingThread()) {
            System.out.println("The next mouse press happened");
            synchronized (NMPWaitingThread) {
                nextMousePress = new Point(x, y);
                NMPWaitingThread.notify();
            }
            System.out.println("NMPWaitingThread notify()'d.");
        }
    }

    private void cancelNextMousePress() {
        if (isANextMousePressWaitingThread()) {
            synchronized (NMPWaitingThread) {
                NMPWTCanceled = true;
                NMPWaitingThread.notify();
            }
        }
    }
    private AObject nextAObjectTargeted = null;
    private Thread NAOTWaitingThread = null;
    private boolean NAOTWTCanceled = false;

    synchronized AObject getNextAObjectTargeted() {
        //System.out.println("Waiting for an AObject to be targeted...");
        NAOTWTCanceled = false;
        AObject ao;
        NAOTWaitingThread = Thread.currentThread();
        synchronized (Thread.currentThread()) {
            while (nextAObjectTargeted == null) {
                try {
                    Thread.currentThread().wait();
                } catch (InterruptedException ex) {
                }
                if (NAOTWTCanceled) {
                    nextAObjectTargeted = null;
                    break;
                }
            }
        }
        ao = nextAObjectTargeted;
        nextAObjectTargeted = null;
        NAOTWaitingThread = null;
        System.out.println("returning the next AObject targeted. canceled : " + NAOTWTCanceled);
        return ao;
    }

    private boolean isANextObjectTargetedWaitingThread() {
        return NAOTWaitingThread != null;
    }

    public void notifyOfMousePress(int x, int y, int button, int mask) {
        if (isANextMousePressWaitingThread() && button == MouseEvent.BUTTON3) {
            notifyOfNextMousePress(x, y);
        } else if ((mask & MouseEvent.SHIFT_DOWN_MASK) == 0 && button == MouseEvent.BUTTON1) {
            deselectAll();
        } else if (button == MouseEvent.BUTTON3) {
            if (ampMover == null) {
                ampMover = new MoveCmd(getAGV().getRP());
            }
            ampMover.executeOn(selected, x, y);
        }
        //System.out.println("AMP_PRESSED");
    }

    public void notifyOfMousePress(AObject objectClicked, MouseEvent e) {
        notifyOfMousePress(objectClicked.getX(), objectClicked.getY(), e.getButton(), e.getModifiersEx());
    }

    private void cancelNextAObectTargeted() {
        if (isANextObjectTargetedWaitingThread()) {
            synchronized (NAOTWaitingThread) {
                NAOTWTCanceled = true;
                NAOTWaitingThread.notify();
            }
        }
    }

    public void notifyOfTargetiveMousePress(AObject ao) {
        if (isANextObjectTargetedWaitingThread()) {
            System.out.println("the next AObject was targeted");
            synchronized (NAOTWaitingThread) {
                nextAObjectTargeted = ao;
                NAOTWaitingThread.notify();
            }
            System.out.println("NAOTWaitingThread notify()'d");
        }
        notifyOfNextMousePress(ao.getX() + ao.getWidth() / 2, ao.getY() + ao.getHealth() / 2);
    }

    private void cancelAllUIWaitingThreads() {
        cancelNextAObectTargeted();
        cancelNextMousePress();
    }

    public AObject getAoAt(int x, int y) {
        if (getGM() != null) {
            try {
                GridObject go = getGM().getGoAtPixel(x, y);
                if (go instanceof AObject && go.getBounds().contains(x, y)) {
                    return ((AObject) go);
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                return null;
            }
        }
        return null;
    }

    //====================Mouse Listeners========================
    @Override
    public void mouseClicked(MouseEvent e) {
        AObject ao = getAoAt(e.getX(), e.getY());
        if (ao != null) {
            ao.mouseClicked(e);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        AObject ao = getAoAt(e.getX(), e.getY());
        if (ao != null) {
            ao.mousePressed(e);
        } else {
            notifyOfMousePress(e.getX(), e.getY(), e.getButton(), e.getModifiersEx());
        }
        //System.out.println("AMP_PRESSED");
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        AObject ao = getAoAt(e.getX(), e.getY());
        if (ao != null) {
            ao.mouseReleased(e);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        return;
    }
    private AObject lastAoEntered;

    @Override
    public void mouseMoved(MouseEvent e) {
        AObject ao = getAoAt(e.getX(), e.getY());
        if (ao != null) {
            if (ao != lastAoEntered) {
                if (lastAoEntered != null) {
                    lastAoEntered.mouseExited(e);
                }
                lastAoEntered = ao;
                ao.mouseEntered(e);
            }
        } else if (lastAoEntered != null) {
            lastAoEntered.mouseExited(e);
            lastAoEntered = null;
        }
    }

    //==============================Key Listeners=================================
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        //TODO find a better way to do commands from the keyboard
        getAGV().getACDM().dispatchEvent(new KeyEvent(getAGV().getACDM(), e.getID(), e.getWhen(), (e.getModifiers() | KeyEvent.ALT_DOWN_MASK), e.getKeyCode(), e.getKeyChar()));
        //System.out.println("AMP_KEY_PRESSED");
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}
